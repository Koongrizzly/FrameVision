

def _infer_image_format_from_input(job_args):
    try:
        p = str(job_args.get("input_path") or job_args.get("source") or "")
        suf = Path(p).suffix.lower().lstrip(".")
        if suf == "jpeg":
            suf = "jpg"
        # Allow common still formats
        if suf in ("jpg","png","webp","bmp","tif","tiff"):
            return "tiff" if suf == "tif" else suf
    except Exception:
        pass
    return None
# FrameVision worker V2.0 — NCNN wiring
import json, time, subprocess, os, re, shutil, sys
from pathlib import Path
try:
    from PIL import Image
except Exception:
    Image = None

# --- No-overwrite helper: pick a new name if target exists ---
def _unique_path(p: Path) -> Path:
    try:
        p = Path(p)
        if not p.exists():
            return p
        stem, suffix = p.stem, p.suffix
        i = 1
        while True:
            cand = p.with_name(f"{stem}_{i:03d}{suffix}")
            if not cand.exists():
                return cand
            i += 1
    except Exception:
        return Path(p)



# --- Quiet mode: suppress CLIP 77-token complaints & other noisy logs ---
try:
    import os as _w_os, warnings as _w_warnings
    _w_os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
    _w_os.environ.setdefault("BITSANDBYTES_NOWELCOME", "1")
    _w_os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
    try:
        from transformers.utils import logging as _w_hf_logging
        _w_hf_logging.set_verbosity_error()
    except Exception:
        pass
    try:
        from diffusers.utils import logging as _w_df_logging
        _w_df_logging.set_verbosity_error()
        try:
            _w_df_logging.disable_progress_bar()
        except Exception:
            pass
    except Exception:
        pass
    try:
        import logging as _w_pylogging
        _w_pylogging.getLogger("transformers").setLevel(_w_pylogging.ERROR)
        _w_pylogging.getLogger("transformers.tokenization_utils_base").setLevel(_w_pylogging.ERROR)
    except Exception:
        pass
    try:
        _w_warnings.filterwarnings(
            "ignore",
            message=r".*CLIP can only handle sequences up to 77 tokens.*",
            category=UserWarning,
        )
        _w_warnings.filterwarnings(
            "ignore",
            message=r"The following part of your input was truncated because CLIP can only handle sequences up to 77 tokens:.*",
            category=UserWarning,
        )
    except Exception:
        pass
except Exception:
    pass

import warnings

# 1) Suppress the original scary warning
warnings.filterwarnings(
    "ignore",
    message="torch.distributed.reduce_op is deprecated, please use torch.distributed.ReduceOp instead",
    category=UserWarning,
)

# 2) Print your own friendlier note once at startup
print("[torch info] Using an older internal PyTorch alias; this warning is harmless and can be ignored.")


# -----------------------------------------------------------------------

ROOT = Path(".").resolve()
BASE = ROOT

def _safe_unlink(p):
    try:
        Path(p).unlink(missing_ok=True)
    except Exception:
        try:
            if Path(p).exists():
                Path(p).unlink()
        except Exception:
            pass

def _safe_rmtree(p):
    try:
        shutil.rmtree(p, ignore_errors=True)
    except Exception:
        pass


# ---- Media type helpers ----
IMAGE_EXTS = {".png",".jpg",".jpeg",".bmp",".webp",".tif",".tiff",".gif"}
VIDEO_EXTS = {".mp4",".mov",".mkv",".avi",".webm",".m4v"}

def is_image_path(p: Path) -> bool:
    try:
        return p.suffix.lower() in IMAGE_EXTS
    except Exception:
        return False

def is_video_path(p: Path) -> bool:
    try:
        return p.suffix.lower() in VIDEO_EXTS
    except Exception:
        return False

# ---- Executable resolution (sanity-filtered) ----
def resolve_upscaler_exe(cfg: dict, mani: dict, model_name: str):
    """Return (canonical_model_name, exe_path) for upscalers only (NO RIFE)."""
    # 1) Manifest-relative exe path
    try:
        root = Path(mani.get("root")) if mani.get("root") else ROOT
    except Exception:
        root = ROOT
    entry = (mani.get("models") or {}).get("upscalers", {}).get(model_name) if mani else None
    if entry and isinstance(entry, dict):
        exe_rel = (entry or {}).get('exe') or ''
        if exe_rel:
            exe_path = (root / exe_rel)
            if exe_path.exists() and exe_path.is_file():
                return (model_name, exe_path)

    # 2) Search models folder for known upscaler executables
    models_dir = _resolve_models_folder(cfg)
    if models_dir and models_dir.exists():
        candidates = [
            "realesrgan-ncnn-vulkan.exe", "realesrgan-ncnn-vulkan",
            "swinir-ncnn-vulkan.exe",     "swinir-ncnn-vulkan",
            "waifu2x-ncnn-vulkan.exe",    "waifu2x-ncnn-vulkan",
            "lapsrn-ncnn-vulkan.exe",     "lapsrn-ncnn-vulkan",
        ]
        try:
            for name in candidates:
                for p in models_dir.rglob(name):
                    if p.is_file():
                        return (model_name, p)
        except Exception:
            pass
    return (model_name, None)

def resolve_rife_exe(cfg: dict, mani: dict):
    """Locate rife executable for interpolation jobs only."""
    models_dir = _resolve_models_folder(cfg)
    if models_dir and models_dir.exists():
        for name in ["rife-ncnn-vulkan.exe","rife-ncnn-vulkan"]:
            try:
                for p in models_dir.rglob(name):
                    if p.is_file():
                        return p
            except Exception:
                pass
    # Fallback to manifest exe if provided
    try:
        root = Path(mani.get("root")) if mani.get("root") else ROOT
        entry = (mani.get("models") or {}).get("interpolators", {}).get("rife") if mani else None
        if entry and isinstance(entry, dict):
            exe_rel = (entry or {}).get('exe') or ''
            if exe_rel:
                exe_path = (root / exe_rel)
                if exe_path.exists() and exe_path.is_file():
                    return exe_path
    except Exception:
        pass
    return None
def _resolve_models_folder(cfg: dict) -> Path:
    # Prefer config if valid; otherwise fall back to typical locations.
    try:
        cand = Path(cfg.get("models_folder", "")).expanduser()
        if str(cand).strip() and cand.exists():
            return cand
    except Exception:
        pass
    # Common fallbacks
    for p in [BASE/'models', Path('.')/'FrameVision'/'models', Path('.')/'models']:
        try:
            if p.exists():
                return p
        except Exception:
            continue
    return BASE/'models'


LEGACY_BASES = [ROOT / "FrameVision", ROOT / "framevision", ROOT / "Framevis*"]
def _migrate_legacy_tree():
    base = BASE
    for p in ["output/video","output/trims","output/screenshots","output/descriptions","output/_temp",
              "jobs/pending","jobs/running","jobs/done","jobs/failed","logs"]:
        (base / p).mkdir(parents=True, exist_ok=True)
    for legacy in LEGACY_BASES:
        if not legacy.exists() or legacy == base:
            continue
        for rel in ["output/video","output/trims","output/screenshots","output/descriptions","output/_temp",
                    "jobs/pending","jobs/running","jobs/done","jobs/failed","logs"]:
            src = legacy / rel
            dst = base / rel
            if not src.exists():
                continue
            dst.mkdir(parents=True, exist_ok=True)
            for pth in src.rglob("*"):
                if pth.is_dir():
                    continue
                relp = pth.relative_to(src)
                target = dst / relp
                target.parent.mkdir(parents=True, exist_ok=True)
                try:
                    if not target.exists():
                        pth.replace(target)
                    else:
                        stem, suff = target.stem, target.suffix
                        alt = target.with_name(f"{stem}_migrated{suff}")
                        pth.replace(alt)
                except Exception:
                    pass

_migrate_legacy_tree()

JOBS = { "pending": BASE/"jobs"/"pending", "running": BASE/"jobs"/"running", "done": BASE/"jobs"/"done", "failed": BASE/"jobs"/"failed" }
LOGS_DIR = BASE / "logs"
LOGS_DIR.mkdir(parents=True, exist_ok=True)
HEARTBEAT = LOGS_DIR / "worker_heartbeat.txt"
PROGRESS_FILE = None
RUNNING_JSON_FILE = None
for p in JOBS.values(): p.mkdir(parents=True, exist_ok=True)

CONFIG_PATH = BASE / "config.json"
MANIFEST_PATH = ROOT / "models_manifest.json"

# --- Robust model resolution helpers (idempotent) ---
def _find_manifest_entry(model_name: str, mani: dict):
    if not model_name:
        return None, None
    n = str(model_name).strip()
    if not n:
        return None, None
    nl = n.lower()
    for k, v in mani.items():
        if str(k).lower() == nl:
            return k, v
    if 'realesrgan' in nl or 'realesr' in nl: return 'RealESR-general-x4v3', mani.get('RealESR-general-x4v3', {})
    if 'swinir' in nl: return 'SwinIR-x4', mani.get('SwinIR-x4', {})
    if 'lapsrn' in nl: return 'LapSRN-x4', mani.get('LapSRN-x4', {})
    return None, None

def _resolve_model_exe(cfg: dict, mani: dict, model_name: str):
    # Prefer manifest; if not found, auto-detect under models_folder.
    # Works even when model_name is missing or doesn't include "realesr"/"swinir".
    canon, entry = _find_manifest_entry(model_name, mani)
    try:
        root = _resolve_models_folder(cfg)
    except Exception:
        root = ROOT

    # 1) Manifest-relative exe path
    exe_rel = (entry or {}).get('exe') or ''
    if exe_rel:
        exe_path = (root / exe_rel)
        if exe_path.exists() and exe_path.is_file():
            return (canon or model_name), exe_path

    # 2) Auto-detect executables under models folder
    # Candidate tags and common filenames
    CANDS = [
        ("realesrgan", ["realesrgan-ncnn-vulkan.exe", "realesrgan-ncnn-vulkan"]),
        ("swinir",    ["swinir-ncnn-vulkan.exe", "swinir-ncnn-vulkan"]),
        ("waifu2x",   ["waifu2x-ncnn-vulkan.exe", "waifu2x-ncnn-vulkan"]),
        ("lapsrn",    ["lapsrn-ncnn-vulkan.exe", "lapsrn"]),
    ]
    m = (canon or model_name or "").lower()
    # Prioritize by requested model tag if present
    ordered = CANDS
    if m:
        ordered = [c for c in CANDS if c[0] in m] + [c for c in CANDS if c[0] not in m]

    # Search by common names first
    try:
        for tag, names in ordered:
            for name in names:
                # exact file
                for p in root.rglob(name):
                    try:
                        if p.is_file() and (p.suffix.lower()=='.exe' or os.name!='nt'):
                            return (canon or tag), p
                    except Exception:
                        pass
                # wildcard around basename
                base = name.split('.')[0]
                for p in root.rglob(f"*{base}*"):
                    try:
                        if p.is_file() and (p.suffix.lower()=='.exe' or os.name!='nt'):
                            return (canon or tag), p
                    except Exception:
                        pass
    except Exception:
        pass

    # 3) Last resort: any executable under models folder
    try:
        any_pat = "*.exe" if os.name=="nt" else "*"
        for p in root.rglob(any_pat):
            try:
                if p.is_file():
                    return (canon or model_name or "realesrgan"), p
            except Exception:
                pass
    except Exception:
        pass

    return (canon or model_name), None


def load_config():
    try: return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception: return {}

def manifest():
    try: return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    except Exception: return {}

def run(cmd):
    env = os.environ.copy()
    env.setdefault("PYTHONUTF8", "1")
    env.setdefault("PYTHONIOENCODING", "utf-8")
    try:
        LOGS = ROOT/"logs"; LOGS.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime("%Y%m%d_%H%M%S")
        log_file = LOGS/f"run_{stamp}.log"
        with open(log_file, "w", encoding="utf-8") as f:
            f.write("CMD: " + " ".join([str(x) for x in cmd]) + "\n\n")
            p = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            for line in p.stdout:
                try:
                    f.write(line)
                except Exception:
                    pass
            code = p.wait()
            f.write(f"\nEXIT CODE: {code}\n")
        return code
    except Exception:
        return subprocess.call(cmd, env=env)
def _progress_set(pct: int):
    try:
        global PROGRESS_FILE, RUNNING_JSON_FILE
        # Write sidecar progress file (optional consumer)
        if PROGRESS_FILE:
            p = Path(PROGRESS_FILE)
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(p.suffix + ".tmp")
            data = json.dumps({"pct": int(max(0, min(100, pct)))}, ensure_ascii=False)
            tmp.write_text(data, encoding="utf-8")
            try:
                tmp.replace(p)
            except Exception:
                # fallback write directly
                p.write_text(data, encoding="utf-8")

        # Patch running job JSON for UI (pct + elapsed + eta)
        if RUNNING_JSON_FILE and int(pct) >= 0:
            try:
                rj = Path(RUNNING_JSON_FILE)
                j = json.loads(rj.read_text(encoding="utf-8")) if rj.exists() else {}
                ipct = int(max(0, min(100, pct)))
                changed = (j.get("pct") != ipct)
                j["pct"] = ipct

                # Compute timing fields from started_at
                start = j.get("started_at")
                if start:
                    # Parse "YYYY-mm-dd HH:MM:SS"
                    import time as _t
                    try:
                        t0 = _t.mktime(_t.strptime(str(start), "%Y-%m-%d %H:%M:%S"))
                    except Exception:
                        # Try ISO format fallback
                        try:
                            from datetime import datetime as _dt
                            t0 = _dt.fromisoformat(str(start)).timestamp()
                        except Exception:
                            t0 = None
                    if t0:
                        elapsed = int(max(0, _t.time() - t0))
                        if j.get("elapsed_sec") != elapsed:
                            changed = True
                        j["elapsed_sec"] = elapsed
                        if 0 < ipct < 100:
                            try:
                                total_est = elapsed / (ipct / 100.0)
                                eta = int(max(1, total_est - elapsed))
                            except Exception:
                                eta = None
                            if eta is not None and j.get("eta_sec") != eta:
                                changed = True
                            j["eta_sec"] = eta
                        else:
                            if "eta_sec" in j:
                                changed = True
                            j["eta_sec"] = 0 if ipct >= 100 else None

                if changed:
                    tmpj = rj.with_suffix(rj.suffix + ".tmp")
                    tmpj.write_text(json.dumps(j, indent=2), encoding="utf-8")
                    try:
                        tmpj.replace(rj)
                    except Exception:
                        rj.write_text(json.dumps(j, indent=2), encoding="utf-8")
            except Exception:
                pass
    except Exception:
        pass


def ffmpeg_path():
    cand = [ROOT/"bin"/("ffmpeg.exe" if os.name=="nt" else "ffmpeg"), ROOT/"presets"/"bin"/("ffmpeg.exe" if os.name=="nt" else "ffmpeg"), "ffmpeg"]
    for c in cand:
        try: subprocess.check_output([str(c), "-version"], stderr=subprocess.STDOUT)
        except Exception: continue
        return str(c)
    return "ffmpeg"

FFMPEG = ffmpeg_path()

def _ffprobe_bin():
    cands = [ROOT/"bin"/('ffprobe.exe' if os.name=='nt' else 'ffprobe'),
             ROOT/"presets"/"bin"/('ffprobe.exe' if os.name=='nt' else 'ffprobe'),
             str(FFMPEG).replace("ffmpeg","ffprobe"),
             "ffprobe"]
    for c in cands:
        try:
            subprocess.check_output([str(c), "-version"], stderr=subprocess.STDOUT)
            return str(c)
        except Exception:
            continue
    return "ffprobe"

def _probe_src_fps(p: Path) -> str:
    try:
        FP = _ffprobe_bin()
        out = subprocess.check_output(
            [FP, "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=avg_frame_rate,r_frame_rate",
             "-of", "csv=p=0", str(p)], stderr=subprocess.STDOUT
        ).decode("utf-8","ignore").strip().splitlines()
        for val in out:
            val = (val or "").strip()
            if not val or val in ("0/0","0","N/A"):
                continue
            if "/" in val:
                a,b = val.split("/",1)
                try:
                    if float(b) != 0:
                        return val
                except Exception:
                    pass
            try:
                f = float(val)
                if f > 0: return f"{f:g}"
            except Exception:
                pass
    except Exception:
        pass
    return "30"



def _normalize_realesr_model(model_name: str, factor: int|float|str):
    """
    Accepts names like:
      - "realesrgan-x4plus", "realesrgan-x4plus-anime"
      - "realesr-general-x4v3", "realesr-general-wdn-x4v3"
      - "realesr-animevideov3-x2", "realesr-animevideov3-x3", "realesr-animevideov3-x4"
    Returns (base_name_without_scale_suffix, scale_int)
    """
    try:
        name = (model_name or "").strip()
    except Exception:
        name = ""
    # Pull trailing -xN if present
    m = re.search(r"(?i)(.*?)(?:-x(\d+))?$", name)
    base = (m.group(1) if m else name) or ""
    scale = int(m.group(2)) if (m and m.group(2)) else int(float(factor or 4))
    # Canonicalization for some common aliases
    aliases = {
        "RealESRGAN-x4plus": "realesrgan-x4plus",
        "RealESRGAN-anime-x4plus": "realesrgan-x4plus-anime",
        "RealESR-general-x4v3": "realesr-general-x4v3",
        "RealESR-general-wdn-x4v3": "realesr-general-wdn-x4v3",
    }
    base = aliases.get(base, base).lower()
    return base, int(scale)

def build_realesrgan_cmd(exe, inp, out, factor, model_name, models_dir=None, is_dir=False):
    base, s = _normalize_realesr_model(model_name, factor)
    cmd = [exe, "-i", str(inp), "-o", str(out), "-s", str(int(s)), "-n", base]
    if models_dir:
        cmd += ["-m", str(models_dir)]
    if is_dir:
        cmd += ["-f", "png"]
    return cmd


def build_swinir_cmd(exe, inp, out, factor):
    s = int(factor); return [exe, "-i", str(inp), "-o", str(out), "-s", str(s)]

def build_lapsrn_cmd(exe, inp, out, factor):
    s = int(factor); return [exe, "-i", str(inp), "-o", str(out), "-s", str(s)]


def upscale_video(job, cfg, mani):
    print("[worker] upscale_video: start", job.get("input"))
    inp = Path(job["input"]); out_dir = Path(job["out_dir"]); out_dir.mkdir(parents=True, exist_ok=True)
    factor = int(job["args"].get("factor", 4))
    model_name = job["args"].get("model","RealESRGAN-x4plus")
    model_name, exe_path = resolve_upscaler_exe(cfg, mani, model_name)
    out = out_dir / f"{inp.stem}_x{factor}.mp4"

    out = _unique_path(out)
    # Prepare potential temp dirs (some may not be used; we'll still try to delete them in finally)
    frames = out_dir / f"{inp.stem}_x{factor}_frames"
    up = out_dir / f"{inp.stem}_x{factor}_up"
    work = out_dir / f"{inp.stem}_x{factor}_work"  # also clean UI-created temp dirs if present

    _hb_thr = None
    _hb_stop = {"run": False}

    def _stop_hb():
        try:
            _hb_stop["run"] = False
            if _hb_thr is not None:
                _hb_thr.join(timeout=0.2)
        except Exception:
            pass

    try:
        if exe_path and exe_path.exists() and exe_path.is_file():
            print(f"[worker] Using model '{model_name}' at {exe_path}")
            # 1) Extract frames
            frames.mkdir(parents=True, exist_ok=True)
            code = run([FFMPEG,"-y","-i",str(inp), str(frames/"%06d.png")])
            if code != 0:
                return 1

            # 2) Upscale frames (batch dir-mode for RealESRGAN; per-frame for others)
            up.mkdir(parents=True, exist_ok=True)
            try:
                total_frames = len(list(frames.glob("*.png")))
            except Exception:
                total_frames = 0
            try:
                _progress_set(10)
            except Exception:
                pass

            import threading as _th, time as _time
            _hb_stop["run"] = True
            _hb_state = {"last": -1}
            def _hb_loop():
                while _hb_stop.get("run", False):
                    try:
                        done = len(list(up.glob("*.png")))
                        if total_frames > 0:
                            pct = 10.0 + min(85.0, (done / total_frames) * 85.0)
                            ipct = int(pct)
                            if ipct != _hb_state["last"]:
                                _progress_set(ipct)
                                _hb_state["last"] = ipct
                    except Exception:
                        pass
                    _time.sleep(1.0)
            _hb_thr = _th.Thread(target=_hb_loop, daemon=True)
            try:
                _hb_thr.start()
            except Exception:
                pass

            m = str(model_name).lower()
            if ("realesr" in m) or ("realesrgan" in m):
                cmd = build_realesrgan_cmd(str(exe_path), frames, up, factor, model_name, models_dir=Path(exe_path).parent, is_dir=True)
                if run(cmd)!=0:
                    return 1
            else:
                for png in sorted(frames.glob("*.png")):
                    if "swinir" in m:
                        cmd = build_swinir_cmd(str(exe_path), png, up/png.name, factor)
                    elif "lapsrn" in m:
                        cmd = build_lapsrn_cmd(str(exe_path), png, up/png.name, factor)
                    else:
                        cmd = [FFMPEG,"-y","-i",str(png),"-vf",f"scale=iw*{factor}:ih*{factor}:flags=lanczos","-frames:v","1",str(up/png.name)]
                    if run(cmd)!=0:
                        return 1

            # 3) Re-encode
            _stop_hb()
            try:
                _progress_set(90)
            except Exception:
                pass

            enc = [FFMPEG,"-y","-framerate", _probe_src_fps(inp), "-i", str(up/"%06d.png"),"-i",str(inp),"-map","0:v:0","-map","1:a:0?","-c:a","copy","-c:v","libx264","-preset","veryfast","-pix_fmt","yuv420p","-vsync","cfr","-r",_probe_src_fps(inp),"-movflags","+faststart",str(out)]
            if run(enc)!=0:
                return 1
            try:
                _progress_set(100)
            except Exception:
                pass
            try:
                job['produced'] = str(out)
            except Exception:
                pass
            return 0
        else:
            # Fallback: ffmpeg scale (no model)
            print("[worker] No model exe found, using ffmpeg scale fallback")
            code = run([FFMPEG,"-y","-i",str(inp),"-vf",f"scale=iw*{factor}:ih*{factor}:flags=lanczos", str(out)])
            try:
                _progress_set(100)
            except Exception:
                pass
            if code == 0:
                try:
                    job['produced'] = str(out)
                except Exception:
                    pass
            return code
    finally:
        # Always try to clean temp dirs; ignore errors
        _stop_hb()
        for d in (frames, up, work / "in", work / "out", work):
            try:
                if d.exists():
                    _safe_rmtree(d)
            except Exception:
                pass

def tools_ffmpeg(job, cfg, mani):

    try:
        import shlex
        import pathlib  # ensure available even if not imported at module level
        args = job.get("args", {}) or {}
        cmd = args.get("ffmpeg_cmd") or args.get("cmd") or job.get("cmd")
        # Normalize to list
        if isinstance(cmd, str):
            try:
                cmd = shlex.split(cmd)
            except Exception:
                cmd = cmd.strip().split()
        if not isinstance(cmd, (list, tuple)) or len(cmd) == 0:
            try:
                job['error'] = "No ffmpeg command provided (expected args.ffmpeg_cmd, args.cmd, or job.cmd)."
            except Exception:
                pass
            return 1

        # Ensure output directory exists if job provides one
        try:
            out_dir = job.get("out_dir")
            if out_dir:
                pathlib.Path(out_dir).mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        # If args['outfile'] is set, create its parent
        try:
            outfile = args.get("outfile")
            if outfile:
                pathlib.Path(outfile).parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass

        # Record the normalized command for visibility
        try:
            job['cmd'] = " ".join(str(x) for x in cmd)
        except Exception:
            pass

        return run([str(x) for x in cmd])
    except Exception as e:
        try:
            job['error'] = f"tools_ffmpeg exception: {e}"
        except Exception:
            pass
        return 1
def upscale_photo(job, cfg, mani):
    print("[worker] upscale_photo: start", job.get("input"))
    inp = Path(job["input"]); out_dir = Path(job["out_dir"]); out_dir.mkdir(parents=True, exist_ok=True)
    factor = int(job["args"].get("factor", 4)); fmt = (job["args"].get("format") or _infer_image_format_from_input(job["args"]) or "png").lower()
    model_name = job["args"].get("model","RealESRGAN-x4plus")
    model_name, exe_path = resolve_upscaler_exe(cfg, mani, model_name)
    out = out_dir / f"{inp.stem}_x{factor}.{fmt}"
    out = _unique_path(out)
    try:
        _progress_set(5)
    except Exception:
        pass

    # Decode-prep still images to a temp RGB PNG to avoid alpha/codec quirks
    src_in = inp
    tmp_rgb = None
    try:
        ext = inp.suffix.lower()
        if Image is not None and ext in IMAGE_EXTS:
            tmp_rgb = out_dir / f"{inp.stem}_probe_rgb.png"
            im = Image.open(str(inp))
            try:
                im.seek(0)  # GIF: first frame
            except Exception:
                pass
            im = im.convert("RGB")
            im.save(str(tmp_rgb), format="PNG")
            if tmp_rgb.exists():
                src_in = tmp_rgb
        elif Image is None and ext in IMAGE_EXTS:
            # Fallback to ffmpeg if Pillow unavailable
            tmp_rgb = out_dir / f"{inp.stem}_probe_rgb.png"
            code = run([FFMPEG,"-y","-i",str(inp),"-vf","format=rgb24","-frames:v","1",str(tmp_rgb)])
            if code == 0 and tmp_rgb.exists():
                src_in = tmp_rgb
    except Exception:
        pass

    try:
        if exe_path and exe_path.exists() and exe_path.is_file():
            m = str(model_name).lower()
            if ("realesr" in m) or ("realesrgan" in m):
                models_dir_guess = None
                try:
                    models_dir_guess = Path(exe_path).parent
                except Exception:
                    models_dir_guess = None
                try:
                    # If not clearly in a realsr folder, fall back to models/realesrgan under the configured models folder
                    if not models_dir_guess or all(tag not in str(models_dir_guess).lower() for tag in ("realesr", "realesrgan")):
                        models_dir_guess = _resolve_models_folder(cfg) / "realesrgan"
                except Exception:
                    pass
                cmd = build_realesrgan_cmd(str(exe_path), src_in, out, factor, model_name, models_dir=models_dir_guess)
            elif "swinir" in m:
                cmd = build_swinir_cmd(str(exe_path), src_in, out, factor)
            elif "lapsrn" in m:
                cmd = build_lapsrn_cmd(str(exe_path), src_in, out, factor)
            else:
                # Unknown model tag, fallback to ffmpeg scaling
                cmd = [FFMPEG,"-y","-i",str(src_in),"-vf",f"scale=iw*{factor}:ih*{factor}:flags=lanczos","-frames:v","1",str(out)]
            code = run(cmd)
            try:
                job['cmd'] = ' '.join([str(x) for x in cmd])
            except Exception:
                pass
            # ## PATCH set produced after model-exe
            try:
                if code == 0:
                    job['produced'] = str(out)
            except Exception:
                pass

            if code == 0 and not out.exists():
                _mark_error(job, 'Upscale finished but output file missing.')
                return 2
            return code

        # No model exe -> fallback upscale with ffmpeg
        cmd = [FFMPEG,"-y","-i",str(src_in),"-vf",f"scale=iw*{factor}:ih*{factor}:flags=lanczos","-frames:v","1",str(out)]
        code = run(cmd)
        try:
            job['cmd'] = ' '.join(str(x) for x in cmd)
        except Exception:
            pass
        if code == 0:
            try: job['produced'] = str(out)
            except Exception: pass
        return code
    finally:
        # Remove temp RGB probe image if we created one
        if tmp_rgb:
            _safe_unlink(tmp_rgb)


    # No model exe -> fallback upscale with ffmpeg
    cmd = [FFMPEG,"-y","-i",str(src_in),"-vf",f"scale=iw*{factor}:ih*{factor}:flags=lanczos","-frames:v","1",str(out)]
    code = run(cmd)
    try:
        job['cmd'] = ' '.join(str(x) for x in cmd)
    except Exception:
        pass
    if code == 0:
        try: job['produced'] = str(out)
        except Exception: pass
    return code


def txt2img_generate(job, cfg, mani):
    """Queue worker entry for txt2img (SD15/SDXL/Z-Image via helpers.txt2img).

    Strong-fail for Z-Image: when engine == "zimage", we never fall back to the
    legacy Diffusers path. For all other engines we still allow a legacy
    fallback so existing SD15/SDXL jobs keep working.
    """
    # Try the shared helpers.txt2img implementation first
    try:
        from helpers import txt2img as _txt2img
    except BaseException as _imp_err:
        # Option B: if the helpers package is not available (e.g. standalone worker),
        # fall back to importing a local txt2img.py that lives next to worker.py.
        try:
            import txt2img as _txt2img  # type: ignore
            try:
                print("[worker txt2img] helpers package not present; using local txt2img.py (OK)")
            except Exception:
                pass
        except BaseException as _imp_err2:
            try:
                print("[worker txt2img] helpers.txt2img and local txt2img imports failed; falling back to legacy:",
                      _imp_err, "/", _imp_err2)
            except Exception:
                pass
            return _txt2img_generate_legacy(job, cfg, mani)

    # Pull args produced by queue_adapter / enqueue_txt2img
    try:
        args = job.get("args") or {}
    except Exception:
        args = {}

    # Resolve output directory (queue JSON uses job["out_dir"])
    try:
        from pathlib import Path as _P
        out_dir = _P(job.get("out_dir") or "./output/photo/txt2img")
        out_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        out_dir = None

    # Build a UI-style job dict for helpers.txt2img
    helper_job = dict(args)
    if out_dir is not None:
        helper_job.setdefault("output", str(out_dir))

    # Normalise engine selector
    try:
        engine = (str(args.get("engine") or job.get("engine") or "diffusers")).strip().lower()
    except Exception:
        engine = "diffusers"
    helper_job["engine"] = engine
    try:
        print(f"[worker txt2img] job id={job.get('id','?')} engine={engine!r}")
    except Exception:
        pass

    res = None

    # Strict Z-Image path (Option A: no SDXL fallback)
    if engine == "zimage":
        try:
            res = _txt2img.generate_qwen_images(helper_job, progress_cb=None, cancel_event=None)
        except BaseException as e:
            try:
                _mark_error(job, f"Z-Image txt2img failed: {e}")
            except Exception:
                pass
            try:
                print("[worker txt2img] Z-Image backend raised; NOT falling back to legacy SDXL.")
            except Exception:
                pass
            return 2

        if not res or not res.get("files"):
            try:
                _mark_error(job, "Z-Image backend produced no images.")
            except Exception:
                pass
            try:
                print("[worker txt2img] Z-Image backend returned no files; NOT falling back to legacy SDXL.")
            except Exception:
                pass
            return 2
    else:
        # Non-Z-Image engines: allow helper + legacy Diffusers fallback
        try:
            res = _txt2img.generate_qwen_images(helper_job, progress_cb=None, cancel_event=None)
        except Exception as e:
            try:
                _mark_error(job, f"txt2img helper failed: {e}")
            except Exception:
                pass
            try:
                print("[worker txt2img] helper path failed; falling back to legacy diffusers.")
            except Exception:
                pass
            return _txt2img_generate_legacy(job, cfg, mani)

        if not res or not res.get("files"):
            try:
                _mark_error(job, "No images produced (helpers.txt2img returned empty result).")
            except Exception:
                pass
            try:
                print("[worker txt2img] helper produced no images; falling back to legacy diffusers.")
            except Exception:
                pass
            return _txt2img_generate_legacy(job, cfg, mani)

    # Map result back onto the queue job for UI / JSON
    try:
        files = res.get("files") or []
        job["files"] = files
        if files:
            job["produced"] = files[-1]
        backend = res.get("engine") or res.get("backend")
        if backend:
            job["backend"] = backend
        model = res.get("model")
        if model:
            job["model"] = model
    except Exception:
        pass

    try:
        _progress_set(100)
    except Exception:
        pass
    return 0


def _txt2img_generate_legacy(job, cfg, mani):
    # Offline txt2img using local diffusers pipeline
    try:
        import importlib, time
        from pathlib import Path as P

        args = job.get("args") or {}
        try:
            job["title"] = args.get("label") or (args.get("prompt","")[:80] or "txt2img")
        except Exception:
            pass

        out_dir = P(job.get("out_dir") or "."); out_dir.mkdir(parents=True, exist_ok=True)

        # Lazy import torch/diffusers so worker can start even if not installed
        torch = importlib.import_module("torch")
        from diffusers import (
            StableDiffusionPipeline, StableDiffusionXLPipeline,
            EulerAncestralDiscreteScheduler, DPMSolverMultistepScheduler,
            HeunDiscreteScheduler, UniPCMultistepScheduler, DDIMScheduler
        )

        prompt   = args.get("prompt","") or ""
        negative = args.get("negative","") or ""
        steps    = int(args.get("steps") or 30)
        seed     = int(args.get("seed") or 0)
        batch    = int(args.get("batch") or 1)
        width    = int(args.get("width") or 1024)
        height   = int(args.get("height") or 1024)
        cfg_scale= float(args.get("cfg_scale") or 7.5)
        sampler  = (args.get("sampler") or "").strip().lower()
        attn_slice = bool(args.get("attn_slicing"))
        fmt = (args.get("format") or _infer_image_format_from_input(args) or "png").lower()
        name_tmpl= args.get("filename_template") or f"sd_{{seed}}_{{idx:03d}}.{fmt}"

        ROOT = P(__file__).resolve().parent.parent
        default_model = ROOT / "models" / "SD15" / "DreamShaper_8_pruned.safetensors"
        model_path = args.get("model_path") or str(default_model)
        mp = P(model_path)
        if not mp.exists():
            model_path = str(default_model)

        device = "cuda" if getattr(torch.cuda, "is_available", lambda: False)() else "cpu"
        dtype  = torch.float16 if device == "cuda" else torch.float32

        is_sdxl = ("sdxl" in model_path.lower()) or ("sd_xl" in model_path.lower())
        try:
            if is_sdxl:
                try:
                    pipe = StableDiffusionXLPipeline.from_single_file(model_path, torch_dtype=dtype, local_files_only=True)
                except Exception:
                    pipe = StableDiffusionXLPipeline.from_pretrained(model_path, torch_dtype=dtype, local_files_only=True)
            else:
                pipe = StableDiffusionPipeline.from_single_file(model_path, torch_dtype=dtype, local_files_only=True)
        except Exception as e:
            _mark_error(job, f"Model load failed: {e}")
            return 2

        try: pipe = pipe.to(device)
        except Exception: pass

        try:
            sched_map = {
                "euler a": EulerAncestralDiscreteScheduler,
                "dpm++ 2m": DPMSolverMultistepScheduler,
                "heun": HeunDiscreteScheduler,
                "unipc": UniPCMultistepScheduler,
                "ddim": DDIMScheduler,
            }
            if sampler in sched_map:
                pipe.scheduler = sched_map[sampler].from_config(pipe.scheduler.config)
        except Exception:
            pass

        try:
            if hasattr(pipe, "safety_checker") and pipe.safety_checker is not None:
                pipe.safety_checker = (lambda images, **kwargs: (images, [False]*len(images)))
            if attn_slice and hasattr(pipe, "enable_attention_slicing"):
                pipe.enable_attention_slicing()
        except Exception:
            pass

        sp = (args.get("seed_policy") or "fixed").lower()
        if sp == "increment":
            seeds = [seed + i for i in range(max(1, batch))]
        elif sp == "random":
            import random
            rng = random.Random(seed if seed else int(time.time()))
            seeds = [rng.randint(0, 2_147_483_647) for _ in range(max(1, batch))]
        else:
            seeds = [seed for _ in range(max(1, batch))]
        try: job["seeds"] = seeds
        except Exception: pass

        files = []
        for idx, s in enumerate(seeds):
            try:
                g = torch.Generator(device=device)
                if hasattr(g, "manual_seed"):
                    g = g.manual_seed(int(s))
            except Exception:
                g = None

            try:
                out = pipe(
                    prompt=prompt, negative_prompt=negative,
                    width=width, height=height,
                    num_inference_steps=steps, guidance_scale=cfg_scale,
                    generator=g,
                )
                img = out.images[0]
            except Exception as e:
                _mark_error(job, f"inference failed: {e}")
                return 2

            name = name_tmpl.format(seed=s, idx=idx)
            if not name.lower().endswith((".png",".jpg",".jpeg",".webp")):
                name += ".png"
            outp = out_dir / name
            try:
                outp = _unique_path(outp)
                img.save(str(outp))
            except Exception as e:
                _mark_error(job, f"save failed: {e}")
                return 2

            files.append(str(outp))
            try: job["files"] = files[:]
            except Exception: pass
            try: _progress_set(int(100 * (idx+1) / max(1, len(seeds))))
            except Exception: pass

        if files:
            try:
                job["produced"] = files[-1]
                job["backend"] = "diffusers"
            except Exception:
                pass
            return 0

        _mark_error(job, "No images produced.")
        return 2

    except Exception as e:
        try: _mark_error(job, f"txt2img exception: {e}")
        except Exception: pass
        return 2


def ace_generate(job, cfg, mani):
    """Queue worker entry for ACE-Step (text-to-music or audio-to-audio).

    Accepts job types:
      - "ace_text2music"
      - "ace_audio2audio"
      - "ace" / "ace_step" / "ace_music" (aliases)

    This mirrors the logic of helpers/ace.py:AceWorker.run but uses the
    job['args'] dict plus Ace config JSON (presets/setsave/ace.json).
    """
    import subprocess as _subprocess, tempfile as _tempfile, time as _time
    from pathlib import Path as _Path

    # Pull args safely
    try:
        args = job.get("args") or {}
    except Exception:
        args = {}

    # Friendly title / label for the queue row
    try:
        title = args.get("label") or (args.get("prompt", "")[:80] or "ACE-Step")
        job["title"] = title
        try:
            job["label"] = title
        except Exception:
            pass
        try:
            a = job.get("args") or {}
            if not a.get("label"):
                a["label"] = title
            job["args"] = a
        except Exception:
            pass
    except Exception:
        pass

    # Resolve FrameVision root
    root = BASE

    # Load ACE config JSON (same file AceConfig uses)
    ace_cfg = {}
    try:
        cfg_path = root / "presets" / "setsave" / "ace.json"
        if cfg_path.exists():
            ace_cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        ace_cfg = {}

    def _cfg(key, default=None):
        """Prefer explicit job args, then ace.json, then default."""
        v = args.get(key, None)
        if v is None:
            v = ace_cfg.get(key, default)
        return v if v is not None else default

    # Core generation parameters
    prompt = _cfg("prompt", "")
    negative_prompt = _cfg("negative_prompt", "")
    lyrics = _cfg("lyrics", "")
    audio_duration = float(_cfg("audio_duration", 60.0) or 60.0)
    infer_step = int(_cfg("infer_step", 60) or 60)
    guidance_scale = float(_cfg("guidance_scale", 15.0) or 15.0)
    scheduler_type = _cfg("scheduler_type", "euler") or "euler"
    cfg_type = _cfg("cfg_type", "apg") or "apg"

    # Advanced guidance / ERG settings
    omega_scale = float(_cfg("omega_scale", 10.0) or 10.0)
    guidance_interval = float(_cfg("guidance_interval", 0.5) or 0.5)
    guidance_interval_decay = float(_cfg("guidance_interval_decay", 0.0) or 0.0)
    min_guidance_scale = float(_cfg("min_guidance_scale", 3.0) or 3.0)
    guidance_scale_text = float(_cfg("guidance_scale_text", 5.0) or 5.0)
    guidance_scale_lyric = float(_cfg("guidance_scale_lyric", 1.5) or 1.5)
    use_erg_tag = bool(_cfg("use_erg_tag", True))
    use_erg_lyric = bool(_cfg("use_erg_lyric", False))
    use_erg_diffusion = bool(_cfg("use_erg_diffusion", True))

    # Device / precision
    bf16 = bool(_cfg("bf16", True))
    cpu_offload = bool(_cfg("cpu_offload", False))
    overlapped_decode = bool(_cfg("overlapped_decode", False))
    device_id = int(_cfg("device_id", 0) or 0)

    # Seed handling: single-seed text or audio2audio job
    try:
        seed_val = int(_cfg("seed", 0) or 0)
    except Exception:
        seed_val = 0
    if seed_val == 0:
        try:
            import random as _rnd
            seed_val = _rnd.randint(0, 2_147_483_647)
        except Exception:
            seed_val = 0
    actual_seeds = [int(seed_val)]
    manual_seeds = ", ".join(map(str, actual_seeds))

    # OSS steps: list or string
    oss_steps = _cfg("oss_steps", [])
    if isinstance(oss_steps, (list, tuple)):
        oss_steps_str = ", ".join(map(str, oss_steps))
    else:
        oss_steps_str = str(oss_steps or "")

    # Reference audio
    ref_audio_input = str(_cfg("ref_audio_input", "") or "").strip()
    ref_audio_strength = float(_cfg("ref_audio_strength", 0.5) or 0.5)
    if ref_audio_input:
        try:
            p = _Path(ref_audio_input)
            if not p.is_absolute():
                p = (root / p).resolve()
            ref_audio_input = str(p)
        except Exception:
            ref_audio_input = str(ref_audio_input)
        audio2audio_enable = True
    else:
        ref_audio_input = None
        audio2audio_enable = bool(_cfg("audio2audio_enable", False))

    # Output directory
    try:
        out_dir = _Path(job.get("out_dir") or (root / "output" / "ace"))
    except Exception:
        out_dir = root / "output" / "ace"
    try:
        out_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Build descriptive filename using user track name, seed and preset
    try:
        track_name_raw = str(_cfg("track_name", "") or "").strip()
    except Exception:
        track_name_raw = ""
    try:
        preset_name_raw = str(_cfg("preset_name", "") or "").strip()
    except Exception:
        preset_name_raw = ""
    import re as _re
    def _slugify_name(value: str, default: str) -> str:
        value = (value or "").strip()
        if not value:
            return default
        value = _re.sub(r"[^a-zA-Z0-9_]+", "_", value)
        value = value.strip("_") or default
        return value.lower()
    track_slug = _slugify_name(track_name_raw, "track")
    preset_slug = _slugify_name(preset_name_raw, "preset")

    base_seed = actual_seeds[0] if actual_seeds else int(seed_val or 0)
    filename = f"{track_slug}_{base_seed}_{preset_slug}.wav"
    output_path = str(out_dir / filename)

    # Checkpoint directory: use ace.json if it overrides, else default under presets/extra_env
    checkpoint_rel = ace_cfg.get("checkpoint_path", ".ace_env/ACE-Step/checkpoints")
    try:
        checkpoint_path = str((root / checkpoint_rel).resolve())
    except Exception:
        # Fallback: standard location under presets/extra_env
        checkpoint_path = str((root / "presets" / "extra_env" / ".ace_env" / "ACE-Step" / "checkpoints").resolve())

    # Build job payload for the ACE runner
    jobj = {
        "checkpoint_path": checkpoint_path,
        "dtype": "bfloat16" if bf16 else "float32",
        "torch_compile": False,
        "cpu_offload": bool(cpu_offload),
        "overlapped_decode": bool(overlapped_decode),
        "device_id": int(device_id),
        "prompt": prompt,
        "negative_prompt": negative_prompt,
        "lyrics": lyrics,
        "audio_duration": float(audio_duration),
        "infer_step": int(infer_step),
        "guidance_scale": float(guidance_scale),
        "scheduler_type": scheduler_type,
        "cfg_type": cfg_type,
        "manual_seeds": manual_seeds,
        "omega_scale": float(omega_scale),
        "guidance_interval": float(guidance_interval),
        "guidance_interval_decay": float(guidance_interval_decay),
        "min_guidance_scale": float(min_guidance_scale),
        "use_erg_tag": bool(use_erg_tag),
        "use_erg_lyric": bool(use_erg_lyric),
        "use_erg_diffusion": bool(use_erg_diffusion),
        "oss_steps": oss_steps_str,
        "guidance_scale_text": float(guidance_scale_text),
        "guidance_scale_lyric": float(guidance_scale_lyric),
        "audio2audio_enable": bool(audio2audio_enable),
        "ref_audio_strength": float(ref_audio_strength),
        "ref_audio_input": ref_audio_input,
        "output_path": output_path,
    }

    # Write temporary job JSON
    tmp_dir = _Path(_tempfile.gettempdir())
    tmp_path = tmp_dir / f"framevision_ace_job_{os.getpid()}_{int(_time.time())}.json"
    try:
        tmp_path.write_text(json.dumps(jobj), encoding="utf-8")
    except Exception as e:
        _mark_error(job, f"Could not write ACE job file: {e}")
        return 2

    # Determine ACE env Python and runner script (same layout as in helpers/ace.py)
    ace_env_dir = root / "presets" / "extra_env" / ".ace_env"
    ace_repo_dir = ace_env_dir / "ACE-Step"
    if os.name == "nt":
        ace_python = ace_env_dir / "Scripts" / "python.exe"
    else:
        ace_python = ace_env_dir / "bin" / "python"

    runner_script = ace_repo_dir / "framevision_ace_runner.py"
    if not ace_python.exists():
        _mark_error(job, f"ACE env python not found at: {ace_python}")
        return 2
    if not runner_script.exists():
        _mark_error(job, f"ACE runner script not found at: {runner_script}")
        return 2

    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(device_id)

    cmd = [str(ace_python), str(runner_script), str(tmp_path)]

    # Progress/ETA: stream ACE logs and infer "X/Y" style step progress when possible.
    try:
        log_dir = root / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = _time.strftime("%Y%m%d_%H%M%S")
        log_file = log_dir / f"ace_{stamp}.log"
    except Exception:
        log_file = None

    try:
        _progress_set(5)
    except Exception:
        pass

    import re as _re

    step_re = _re.compile(r"(\d+)\s*/\s*(\d+)")
    total_steps = None
    last_step = 0
    last_pct = -1
    start_ts = _time.time()

    def _update_progress():
        nonlocal last_pct
        pct = 5.0
        if total_steps and total_steps > 0:
            frac = max(0.0, min(1.0, float(last_step) / float(total_steps)))
            pct = 5.0 + 90.0 * frac
        else:
            # Fallback: small time-based ramp up to ~25% so very fast jobs aren't stuck at 5%.
            elapsed = max(0.0, _time.time() - start_ts)
            pct = 5.0 + min(20.0, (elapsed / 20.0) * 20.0)
        ipct = int(max(5, min(98, round(pct))))
        if ipct != last_pct:
            try:
                _progress_set(ipct)
            except Exception:
                pass
            last_pct = ipct

    code = 0
    try:
        lf = None
        if log_file is not None:
            try:
                lf = open(log_file, "w", encoding="utf-8")
                lf.write("CMD: " + " ".join(str(x) for x in cmd) + "\n\n")
                lf.flush()
            except Exception:
                lf = None

        p = _subprocess.Popen(
            cmd,
            stdout=_subprocess.PIPE,
            stderr=_subprocess.STDOUT,
            text=True,
            env=env,
        )
        while True:
            line = p.stdout.readline()
            if line == "" and p.poll() is not None:
                break
            if not line:
                _update_progress()
                _time.sleep(0.3)
                continue

            if lf is not None:
                try:
                    lf.write(line)
                except Exception:
                    pass
            try:
                print("[ACE]", line, end="")
            except Exception:
                pass

            try:
                m = step_re.search(line)
            except Exception:
                m = None
            if m:
                try:
                    cur = int(m.group(1))
                    tot = int(m.group(2))
                    if tot > 0:
                        if total_steps is None or total_steps != tot:
                            total_steps = tot
                        if cur > last_step:
                            last_step = min(cur, tot)
                except Exception:
                    pass

            _update_progress()

        code = p.wait()
        if lf is not None:
            try:
                lf.write(f"\nEXIT CODE: {code}\n")
                lf.close()
            except Exception:
                pass
    except Exception as e:
        _mark_error(job, f"ACE-Step runner exception: {e}")
        return 2

    if code != 0:
        _mark_error(job, f"ACE-Step runner failed (code {code}).")
        return 2
    # Success: record produced file and mark 100%
    try:
        job["produced"] = output_path
    except Exception:
        pass
    try:
        _progress_set(100)
    except Exception:
        pass
    return 0


def wan22_generate(job, cfg, mani):
    """
    Queue worker entry for Wan 2.2 TI2V (text2video / image2video) with
    best-effort progress + ETA reporting based on stdout "step" logs.

    Expected job shape:
      type: "wan22_text2video" | "wan22_image2video" | "wan22_ti2v" | "wan22"
      input: optional path to start image for image2video
      out_dir: base output folder (optional – defaults to ./output/video/wan22)
      args: {
          "prompt": str,
          "mode": "text2video" | "image2video" (optional, inferred from type),
          "image": str (start image, for image2video),
          "size": "1280*704" | "704*1280",
          "steps": int,
          "guidance": float | int,
          "guidance_scale": float | int,
          "frames": int,
          "frame_num": int,
          "seed": int,
          "base_seed": int,
          "random_seed": bool | str,
          "save_file": str,
          "output_path": str,
      }
    """
    from pathlib import Path as _Path
    import time as _time
    import re as _re
    global ROOT, BASE

    try:
        args = job.get("args") or {}
    except Exception:
        args = {}

    # Nice title in the queue row
    try:
        title = args.get("label") or (args.get("prompt", "")[:80] or "WAN 2.2")
        job["title"] = title
        # Mirror onto common fields some UIs may read
        try:
            job["label"] = title
        except Exception:
            pass
        try:
            a = job.get("args") or {}
            if not a.get("label"):
                a["label"] = title
            job["args"] = a
        except Exception:
            pass
    except Exception:
        pass

    root = BASE

    # Resolve Wan virtualenv Python
    try:
        if os.name == "nt":
            cand = root / ".wan_venv" / "Scripts" / "python.exe"
        else:
            cand = root / ".wan_venv" / "bin" / "python"
        if cand.exists():
            py = str(cand)
        else:
            py = sys.executable or "python"
    except Exception:
        try:
            py = sys.executable
        except Exception:
            py = "python"

    model_root = root / "models" / "wan22"
    gen = model_root / "generate.py"
    if not gen.exists():
        _mark_error(job, f"Wan2.2 generate.py not found at {gen}")
        return 2

    # Mode inference
    mode = (str(args.get("mode") or "") or "").strip().lower()
    t = str(job.get("type") or "").lower()
    if not mode:
        if "image" in t:
            mode = "image2video"
        else:
            mode = "text2video"

    # Core params
    size_str = (args.get("size") or "1280*704").strip() or "1280*704"
    steps = int(args.get("steps") or args.get("sample_steps") or 30)
    guidance = float(args.get("guidance") or args.get("guidance_scale") or 7)
    frames = int(args.get("frames") or args.get("frame_num") or 121)

    base_seed = int(args.get("seed") or args.get("base_seed") or 42)
    rs = args.get("random_seed")
    if rs in (True, 1, "1", "true", "True", "yes", "on"):
        import random as _rnd
        try:
            base_seed = _rnd.randint(0, 2147483647)
        except Exception:
            pass

    prompt = args.get("prompt", "") or ""
    image = (
        args.get("image")
        or args.get("input_image")
        or args.get("image_path")
        or job.get("input")
        or ""
    )

    # Output folder / file
    try:
        out_dir = _Path(job.get("out_dir") or (BASE / "output" / "video" / "wan22"))
    except Exception:
        out_dir = BASE / "output" / "video" / "wan22"
    out_dir.mkdir(parents=True, exist_ok=True)

    save_file_arg = args.get("save_file") or args.get("output_path") or ""
    if save_file_arg:
        save_path = _Path(save_file_arg)
        if not save_path.is_absolute():
            save_path = out_dir / save_path
    else:
        base_name = args.get("filename") or f"wan22_{job.get('id') or int(time.time())}.mp4"
        if not str(base_name).lower().endswith(".mp4"):
            base_name = f"{base_name}.mp4"
        save_path = out_dir / base_name
    try:
        save_path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Build command
    cmd = [
        py,
        str(gen),
        "--task", "ti2v-5B",
        "--size", size_str,
        "--sample_steps", str(steps),
        "--sample_guide_scale", str(guidance),
        "--base_seed", str(base_seed),
        "--frame_num", str(frames),
        "--ckpt_dir", str(model_root),
        "--convert_model_dtype",
    ]
    if prompt:
        cmd += ["--prompt", prompt]
    if mode == "image2video":
        if not image:
            _mark_error(job, "Wan2.2 image2video mode requires an image path (args['image'] or job['input']).")
            return 2
        cmd += ["--image", str(image)]
    cmd += ["--save_file", str(save_path)]

    # Expose command for debugging
    try:
        job["cmd"] = " ".join(str(x) for x in cmd)
    except Exception:
        pass

    # --- Progress-aware run: 2-phase estimate (steps + post) ---
    # We treat the second phase as roughly equal length to the sampling steps.
    # Progress is estimated from stdout "step X/Y" logs and wall-clock.
    log_dir = ROOT / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    stamp = _time.strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"wan22_{stamp}.log"

    import subprocess as _sp

    # Step / ETA tracking
    start_ts = _time.time()
    first_step_ts = None
    est_step_sec = None
    total_steps = None
    last_step_idx = 0
    est_total_dur = None
    last_pct = -1

    step_re = _re.compile(r"(?i)(?:step[^0-9]*)?(\d+)\s*/\s*(\d+)")

    def _update_progress_from_state():
        nonlocal last_pct, est_total_dur
        now = _time.time()
        elapsed = max(0.0, now - start_ts)

        if total_steps and est_step_sec:
            # Estimated duration for one "phase" (sampling) based on steps.
            phase1_dur = est_step_sec * float(total_steps)
            # Assume phase2 ~= phase1.
            est_total_dur = max(phase1_dur * 2.0, phase1_dur + 1.0)
            if elapsed <= phase1_dur:
                # First phase: clamp by observed step index.
                if total_steps > 0:
                    frac1 = max(0.0, min(1.0, float(last_step_idx) / float(total_steps)))
                else:
                    frac1 = 0.0
                # Map to 0–50%.
                pct = 50.0 * frac1
            else:
                # Second phase: 50–100% over remaining time.
                rem = max(0.1, est_total_dur - phase1_dur)
                frac2 = max(0.0, min(1.0, (elapsed - phase1_dur) / rem))
                pct = 50.0 + 50.0 * frac2
        elif total_steps:
            # We know total steps but not timing yet – just use steps → 0–50%.
            if total_steps > 0:
                frac1 = max(0.0, min(1.0, float(last_step_idx) / float(total_steps)))
            else:
                frac1 = 0.0
            pct = 50.0 * frac1
        else:
            # No info – keep a small "spinner" effect.
            # Do NOT over-commit ETA; just bump to 5% after a bit.
            if elapsed > 5.0:
                pct = 5.0
            else:
                pct = 0.0

        ipct = int(max(0, min(99, round(pct))))
        if ipct != last_pct:
            try:
                _progress_set(ipct)
            except Exception:
                pass
            last_pct = ipct

    try:
        with open(log_file, "w", encoding="utf-8") as lf:
            lf.write("CMD: " + " ".join([str(x) for x in cmd]) + "\n\n")
            lf.flush()
            try:
                _progress_set(0)
            except Exception:
                pass

            env = os.environ.copy()
            env.setdefault("PYTHONUTF8", "1")
            env.setdefault("PYTHONIOENCODING", "utf-8")

            p = _sp.Popen(
                cmd,
                stdout=_sp.PIPE,
                stderr=_sp.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                env=env,
            )
            while True:
                line = p.stdout.readline()
                if line == "" and p.poll() is not None:
                    break
                if not line:
                    # Idle; still update progress from time if we have an estimate.
                    _update_progress_from_state()
                    _time.sleep(0.5)
                    continue

                try:
                    lf.write(line)
                except Exception:
                    pass
                try:
                    print("[WAN22]", line, end="")
                except Exception:
                    pass

                # Try to parse "step X/Y" style logs.
                try:
                    m = step_re.search(line)
                except Exception:
                    m = None
                if m:
                    try:
                        cur = int(m.group(1))
                        tot = int(m.group(2))
                        if tot > 0:
                            if total_steps is None or total_steps != tot:
                                total_steps = tot
                            now = _time.time()
                            if first_step_ts is None:
                                first_step_ts = now
                            if cur > last_step_idx:
                                # Update step-rate estimate from timing.
                                if last_step_idx > 0:
                                    dt = max(0.01, now - step_ts)  # step_ts set below
                                    step_count = max(1, cur - last_step_idx)
                                    sec_per_step = dt / float(step_count)
                                    if est_step_sec is None:
                                        est_step_sec = sec_per_step
                                    else:
                                        # Smooth the estimate.
                                        est_step_sec = (est_step_sec * 0.7) + (sec_per_step * 0.3)
                                last_step_idx = cur
                                step_ts = now
                    except Exception:
                        pass

                # Update progress view
                _update_progress_from_state()

            code = p.wait()
            try:
                _progress_set(100)
            except Exception:
                pass
            lf.write(f"\nEXIT CODE: {code}\n")
    except Exception:
        # As a fallback, run without streaming/progress.
        code = run(cmd)

    if code == 0:
        if save_path.exists():
            try:
                job["produced"] = str(save_path)
            except Exception:
                pass
        else:
            _mark_error(job, f"Wan2.2 finished but output file is missing: {save_path}")
            return 2
    return code


def handle_job(jpath: Path):
    job = json.loads(jpath.read_text(encoding="utf-8"))
    cfg = load_config(); mani = manifest()
    running = JOBS["running"] / jpath.name; jpath.rename(running)

    # progress sidecar path
    try:
        global PROGRESS_FILE
        global RUNNING_JSON_FILE
        RUNNING_JSON_FILE = str(running)
        PROGRESS_FILE = str(running.with_suffix(".progress.json"))
    except Exception:
        pass

    # Mark started
    try:
        job["started_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
        running.write_text(json.dumps(job, indent=2), encoding="utf-8")
    except Exception:
        pass

    t0 = time.time()

    # Validate job type early
    t = job.get("type")
    if not t:
        print("WARN: job missing 'type' — skipping:", running)
        return 1

    # Smart reroute if extension says otherwise
    try:
        inp = Path(job.get("input",""))
        if t == "upscale_video" and is_image_path(inp):
            print("[worker] Reroute: image input detected; using upscale_photo")
            t = "upscale_photo"
        elif t == "upscale_photo" and is_video_path(inp):
            print("[worker] Reroute: video input detected; using upscale_video")
            t = "upscale_video"
        job["type"] = t
    except Exception:
        pass

    try:
        if t=="upscale_video": code = upscale_video(job, cfg, mani)
        elif t=="upscale_photo": code = upscale_photo(job, cfg, mani)
        elif t=='tools_ffmpeg': code = tools_ffmpeg(job, cfg, mani)
        elif t=='rife_interpolate':
            code = rife_interpolate(job, cfg, mani)
        elif t in ('txt2img','txt2img_qwen'):
            code = txt2img_generate(job, cfg, mani)
        elif t in ("wan22_text2video","wan22_image2video","wan22_ti2v","wan22"):
            code = wan22_generate(job, cfg, mani)
        elif t in ("ace_text2music","ace_audio2audio","ace","ace_step","ace_music"):
            code = ace_generate(job, cfg, mani)
        else:
            _mark_error(job, f"Unknown job type: {t}")
            code = 2

        # mark finished
        try:
            job["finished_at"] = time.strftime("%Y-%m-%d %H:%M:%S")
            job["duration_sec"] = int(time.time()-t0)
            running.write_text(json.dumps(job, indent=2), encoding="utf-8")
        except Exception:
            pass
        dest = JOBS["done"] if code==0 else JOBS["failed"]
        try:
            _progress_set(100)
        except Exception:
            pass
        (dest / running.name).write_text(json.dumps(job, indent=2), encoding="utf-8")
        try:
            running.unlink()
        except Exception:
            pass
        return code
    except BaseException as e:
        try:
            _mark_error(job, str(e))
        except Exception:
            pass
        return 1

def main():
    print("FrameVision Worker V2.0 Waiting for jobs in", JOBS["pending"])
    while True:
        try:
            HEARTBEAT.write_text(time.strftime("%Y-%m-%d %H:%M:%S"), encoding="utf-8")
        except Exception:
            pass
        items = sorted(JOBS["pending"].glob("*.json"))
        if not items:
            time.sleep(1.0)
            continue
        handle_job(items[0])

if __name__ == "__main__":
    try:
        main()
    except BaseException as e:
        try:
            print("[worker main] fatal error caught:", e)
        except Exception:
            pass

def _find_rife_exe(cfg: dict, mani: dict):
    names = ["rife-ncnn-vulkan.exe","rife-ncnn-vulkan"]
    cands = []
    try:
        td = cfg.get("tools_dir","")
        if td:
            for n in names:
                cands.append(Path(td)/"rife"/n)
    except Exception:
        pass
    for n in names:
        cands += [ROOT/'bin'/n, ROOT/'presets'/'bin'/n, ROOT/'tools'/'rife'/n, ROOT/n]
    for c in cands:
        if Path(c).exists():
            return str(c)
    return "rife-ncnn-vulkan.exe"



def build_rife_cmd(exe: str, inp: Path, out: Path, args: dict):
    cmd = [str(exe), "-i", str(inp), "-o", str(out)]
    g = int(args.get("gpu", 0)); th = int(args.get("threads", 0))
    if g >= 0: cmd += ["-g", str(g)]
    tfps = int(args.get("target_fps", 0)); fac = int(args.get("factor", 0))
    if tfps > 0: cmd += ["-r", str(tfps)]
    elif fac >= 2: cmd += ["-f", str(fac)]
    net = (args.get("network") or "").strip()
    if net: cmd += ["-n", net]
    models_dir = (args.get("models_dir") or "").strip()
    if models_dir: cmd += ["-m", models_dir]
    if th > 0: cmd += ["-j", str(th)]
    return cmd




def _build_rife_cmd_fallback(exe: str, inp: Path, outp: Path, args: dict, models_dir: str | None) -> list:
    cmd = [exe, "-i", str(inp), "-o", str(outp)]
    net = (args.get("network") or "").strip()
    if net: cmd += ["-n", net]
    gpu = int(args.get("gpu", 0) or 0)
    cmd += ["-g", str(gpu)]
    tfps = int(args.get("target_fps") or 0)
    fac = int(args.get("factor") or 0)
    if tfps > 0:
        cmd += ["-r", str(tfps)]
    elif fac > 0:
        cmd += ["-f", str(fac)]
    th = int(args.get("threads") or 0)
    if th > 0:
        cmd += ["-j", f"{th}:{max(1,th)}:{max(1,th)}"]
    if models_dir:
        cmd += ["-m", str(models_dir)]
    return cmd

def _deep_find_models_dir(root: Path, exe: str | None) -> str | None:
    # Look for a folder that contains rife-v4*/uhd/anime subfolders.
    allowed = ("rife-v4.6","rife-v4","rife-uhd","rife-anime")
    def contains_models(d: Path) -> bool:
        try:
            kids = [x.name.lower() for x in d.iterdir() if x.is_dir()]
        except Exception:
            return False
        return any(any(k.startswith(a) for k in kids) for a in allowed)
    # 1) ROOT/models
    m = root / "models"
    if m.exists() and contains_models(m): return str(m)
    # 2) any nested folder under ROOT/models
    if m.exists():
        for p in m.rglob("*"):
            if p.is_dir() and contains_models(p): return str(p)
    # 3) next to exe
    if exe:
        exedir = Path(exe).parent
        for cand in [exedir / "models"] + [p for p in (exedir).rglob("*") if p.is_dir()]:
            if contains_models(cand): return str(cand)
    return None
def _resolve_rife_exe(exe_override, cfg_root: Path) -> Path | None:
    # Try explicit override
    if exe_override:
        p = Path(exe_override)
        if p.exists():
            return p
        # Windows convenience: allow missing .exe
        try:
            if os.name == "nt" and not p.suffix:
                px = p.with_suffix(".exe")
                if px.exists():
                    return px
        except Exception:
            pass
    # Fallback to existing finder
    try:
        ex = _find_rife_exe(cfg_root, {})  # mani not needed for local search
        if ex and Path(ex).exists():
            return Path(ex)
    except Exception:
        pass
    return None
def rife_interpolate(job: dict, cfg: dict, mani: dict):
    inp = Path(job.get("input",""))
    out_dir = Path(job.get("out_dir",".")); out_dir.mkdir(parents=True, exist_ok=True)
    args = job.get("args",{}) or {}
    fmt = str(args.get("format","mp4")).lower()
    preview_sec = int(args.get("preview_seconds", 0))

    # Guard
    if not inp.exists():
        _mark_error(job, "Input file not found.")
        return 2
    if inp.suffix.lower() in (".png",".jpg",".jpeg",".webp",".bmp",".tif",".tiff"):
        _mark_error(job, "Selected file is an image, not a video.")
        return 2

    exe_override = (args.get('exe') or '').strip()
    # Try ONNX backend (future hook)
    try:
        from helpers.rife_core import ensure_bootstrap as _rife_bootstrap  # noqa
        _ = _rife_bootstrap(Path("."))
    except Exception:
        pass

    # If no exe available, fallback to FFmpeg minterpolate (CPU-only)
    if (not exe_override) and (not Path(exe).exists() if isinstance(exe, (str, bytes, os.PathLike)) else True):
        return _fallback_minterpolate_ffmpeg(job, inp, out_dir, args)

    exe = Path(exe_override) if (exe_override and os.path.exists(exe_override)) else _find_rife_exe(cfg, mani)
    if not exe or not Path(exe).exists():
        _mark_error(job, f"RIFE executable not found: {job.get('args',{}).get('exe')}")
        return 127
    job["tool_path"] = str(exe)

    # Resolve output name with pattern
    pattern = (args.get("filename_pattern") or "{name}_rife").strip()
    name = inp.stem
    base_name = (pattern.replace("{name}", name) or f"{name}_rife") + f".{fmt}"
    out_path = out_dir / base_name

    ow = str(args.get("overwrite","ask")).lower()
    if out_path.exists():
        if ow == "skip":
            job["skipped"] = True
            return 0
        if ow != "overwrite":
            # pick unique name
            i = 1
            while out_path.exists():
                out_path = out_dir / (base_name.replace(f".{fmt}", f"_{i}.{fmt}"))
                i += 1

    # If preview, build a clip first
    clip_in = inp
    if preview_sec > 0:
        try:
            FF = ffmpeg_path()
            tmp = out_dir / f"preview_src_{job.get('id','tmp')}.mp4"
            code = run([FF, "-y", "-ss", "0", "-t", str(preview_sec), "-i", str(inp), "-an", "-c", "copy", str(tmp)])
            if code != 0:
                _mark_error(job, "FFmpeg failed to create preview clip.")
                return code
            clip_in = tmp
        except Exception:
            pass

    # Streaming or direct
    streaming = bool(args.get("streaming", False))
    chunk = int(args.get("chunk_seconds", 0))
    if not streaming:
        cmd = build_rife_cmd(exe, clip_in, out_path, args)
        job["cmd"] = " ".join([str(x) for x in cmd])
        code = run(cmd)
        if code == 0:
            try: job['produced'] = str(out_path)
            except Exception: pass
        return code

    # streaming mode
    FF = ffmpeg_path()
    try:
        import subprocess as _sp
        _sp.check_output([FF, "-version"], stderr=_sp.STDOUT)
    except Exception:
        _mark_error(job, "FFmpeg not found but Streaming is ON.")
        return 126
    tmp = out_dir / f"tmp_rife_{job.get('id','tmp')}"; tmp.mkdir(parents=True, exist_ok=True)
    segtime = max(2, int(chunk))
    code = run([FF, "-y", "-i", str(clip_in), "-c","copy","-map","0","-segment_time", str(segtime), "-f","segment", str(tmp/"part_%04d.mp4")])
    if code != 0:
        _mark_error(job, "FFmpeg segmenting failed.")
        return code
    seglist = []
    for p in sorted(tmp.glob("part_*.mp4")):
        seg_out = tmp / f"out_{p.stem}.mp4"
        cmd_seg = build_rife_cmd(exe, p, seg_out, args)
        if (args.get('models_dir') or models_dir_resolved) and '-m' not in cmd_seg:
            cmd_seg += ['-m', str(args.get('models_dir') or models_dir_resolved)]
        code = run(cmd_seg)
        if code != 0:
            _mark_error(job, f"RIFE failed on segment {p.name}.")
            return code
        seglist.append(seg_out)
    listfile = tmp / "list.txt"
    listfile.write_text("\n".join([f"file '{s.as_posix()}'" for s in seglist]), encoding="utf-8")
    code = run([FF, "-y", "-f","concat","-safe","0","-i", str(listfile), "-c","copy", str(out_path)])
    if code != 0:
        _mark_error(job, "FFmpeg concat failed.")
    else:
        try: job['produced'] = str(out_path)
        except Exception: pass
    return code


def _fallback_minterpolate_ffmpeg(job: dict, inp: Path, out_dir: Path, args: dict) -> int:
    """CPU fallback using FFmpeg's minterpolate filter when rife exe is unavailable.
    This ensures out-of-box interpolation without extra downloads.
    """
    FF = ffmpeg_path()
    # Determine target FPS
    target_fps = int(args.get("target_fps") or 0)
    factor = int(args.get("factor") or 2)
    # Try to probe input fps using ffprobe
    def _ffprobe_path():
        cand = [ROOT/"bin"/('ffprobe.exe' if os.name=='nt' else 'ffprobe'), 'ffprobe']
        for c in cand:
            try:
                subprocess.check_output([str(c), "-version"], stderr=subprocess.STDOUT)
            except Exception:
                continue
            return str(c)
        return None
    if target_fps <= 0:
        fps = None
        FP = _ffprobe_path()
        if FP:
            try:
                out = subprocess.check_output([FP, "-v", "0", "-of", "csv=p=0", "-select_streams", "v:0", "-show_entries", "stream=r_frame_rate", str(inp)], stderr=subprocess.STDOUT)
                txt = out.decode("utf-8", errors="ignore").strip()
                if "/" in txt:
                    a,b = txt.split("/"); fps = float(a)/float(b) if float(b)!=0 else None
                else:
                    fps = float(txt)
            except Exception:
                fps = None
        if fps and factor >= 2:
            target_fps = int(round(fps * factor))
        elif fps:
            target_fps = int(round(fps))
        else:
            target_fps = 60 if factor>=2 else 30

    # Output path (atomic write)
    out_name = (args.get("out_name") or (inp.stem + "_interp")).strip()
    fmt = str(args.get("format","mp4")).lower()
    out_path = out_dir / f"{out_name}.{fmt}"
    tmp_path = out_path.with_suffix(out_path.suffix + ".tmp")

    # Construct ffmpeg command
    vf = f"minterpolate=fps={target_fps}:mi_mode=mci:mc_mode=aobmc:vsbmc=1"
    cmd = [FF, "-y", "-i", str(inp), "-vf", vf, "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-c:a", "copy", str(tmp_path)]
    code = run(cmd)
    if code == 0:
        try:
            if out_path.exists():
                out_path.unlink()
        except Exception:
            pass
        try:
            tmp_path.replace(out_path)
        except Exception:
            pass
        try: job['produced'] = str(out_path)
        except Exception: pass
    else:
        _mark_error(job, "FFmpeg minterpolate fallback failed.")
    return code


def _mark_error(job, msg):
    try:
        job['error'] = str(msg)
    except Exception:
        pass
