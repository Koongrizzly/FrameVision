import os
import torch
import warnings

__all__ = [
    "flash_attention",
    "attention",
    "FLASH_ATTN_3_AVAILABLE",
    "FLASH_ATTN_2_AVAILABLE",
]

_DISABLE_FLASH = os.environ.get("FV_WAN_DISABLE_FLASH_ATTENTION", "0").strip().lower() in {"1", "true", "yes", "on"}
_WARNED_LENS_FALLBACK = False
_WARNED_FLASH_FALLBACK = False

_FA2_FLASH_FUNC = None
_FA2_VARLEN_FUNC = None
_FA3_FLASH_FUNC = None
_FA3_VARLEN_FUNC = None

FLASH_ATTN_3_AVAILABLE = False
FLASH_ATTN_2_AVAILABLE = False

if not _DISABLE_FLASH:
    # FlashAttention-3 style import paths first.
    try:
        from flash_attn_interface import flash_attn_func as _FA3_FLASH_FUNC  # type: ignore
        try:
            from flash_attn_interface import flash_attn_varlen_func as _FA3_VARLEN_FUNC  # type: ignore
        except Exception:
            _FA3_VARLEN_FUNC = None
        FLASH_ATTN_3_AVAILABLE = True
    except Exception:
        _FA3_FLASH_FUNC = None
        _FA3_VARLEN_FUNC = None

    # FlashAttention-2 / common package import paths.
    if not FLASH_ATTN_3_AVAILABLE:
        try:
            from flash_attn import flash_attn_func as _FA2_FLASH_FUNC  # type: ignore
            try:
                from flash_attn import flash_attn_varlen_func as _FA2_VARLEN_FUNC  # type: ignore
            except Exception:
                _FA2_VARLEN_FUNC = None
            FLASH_ATTN_2_AVAILABLE = True
        except Exception:
            try:
                from flash_attn.flash_attn_interface import flash_attn_func as _FA2_FLASH_FUNC  # type: ignore
                try:
                    from flash_attn.flash_attn_interface import flash_attn_varlen_func as _FA2_VARLEN_FUNC  # type: ignore
                except Exception:
                    _FA2_VARLEN_FUNC = None
                FLASH_ATTN_2_AVAILABLE = True
            except Exception:
                _FA2_FLASH_FUNC = None
                _FA2_VARLEN_FUNC = None


def _warn_once(kind: str, message: str):
    global _WARNED_LENS_FALLBACK, _WARNED_FLASH_FALLBACK
    if kind == "lens":
        if _WARNED_LENS_FALLBACK:
            return
        _WARNED_LENS_FALLBACK = True
    elif kind == "flash":
        if _WARNED_FLASH_FALLBACK:
            return
        _WARNED_FLASH_FALLBACK = True
    warnings.warn(message, RuntimeWarning)


def _sdpa_fallback(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    dropout_p: float = 0.0,
    softmax_scale=None,
    q_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    deterministic: bool = False,
    dtype=torch.bfloat16,
):
    """
    Fallback attention implementation using PyTorch SDPA.

    Expected shapes:
        q: [B, Lq, Nq, C]
        k: [B, Lk, Nk, C]
        v: [B, Lk, Nk, C]
    """
    if q_lens is not None or k_lens is not None:
        _warn_once(
            "lens",
            "Padding mask is disabled when using scaled_dot_product_attention. "
            "It can have a significant impact on performance.",
        )

    if q_scale is not None:
        q = q * q_scale

    q = q.transpose(1, 2).to(dtype)
    k = k.transpose(1, 2).to(dtype)
    v = v.transpose(1, 2).to(dtype)

    out = torch.nn.functional.scaled_dot_product_attention(
        q,
        k,
        v,
        attn_mask=None,
        is_causal=causal,
        dropout_p=dropout_p,
    )
    return out.transpose(1, 2).contiguous()


def _normalize_lens(lens, batch_size, max_len):
    if lens is None:
        return [int(max_len)] * int(batch_size)
    if isinstance(lens, torch.Tensor):
        vals = [int(x) for x in lens.detach().flatten().tolist()]
    else:
        vals = [int(x) for x in lens]
    if len(vals) != int(batch_size):
        return None
    out = []
    for x in vals:
        if x < 0:
            x = 0
        if x > int(max_len):
            x = int(max_len)
        out.append(x)
    return out


def _unpad_varlen(x, lens_list):
    # x: [B, L, H, D] -> x_unpad: [sum(L_i), H, D]
    pieces = []
    cu = [0]
    total = 0
    for i, ln in enumerate(lens_list):
        ln = int(ln)
        if ln > 0:
            pieces.append(x[i, :ln].contiguous())
        total += ln
        cu.append(total)
    if pieces:
        x_unpad = torch.cat(pieces, dim=0)
    else:
        x_unpad = x.new_zeros((0, x.shape[2], x.shape[3]))
    cu = torch.tensor(cu, device=x.device, dtype=torch.int32)
    max_len = max(lens_list) if lens_list else 0
    return x_unpad, cu, max_len


def _pad_varlen(x_unpad, lens_list, batch_size, max_len):
    # x_unpad: [sum(L_i), H, D] -> [B, L, H, D]
    out = x_unpad.new_zeros((batch_size, max_len, x_unpad.shape[1], x_unpad.shape[2]))
    cursor = 0
    for i, ln in enumerate(lens_list):
        ln = int(ln)
        if ln > 0:
            out[i, :ln] = x_unpad[cursor:cursor + ln]
            cursor += ln
    return out


def _choose_flash_impl(version=None):
    if version == 3:
        if FLASH_ATTN_3_AVAILABLE:
            return _FA3_FLASH_FUNC, _FA3_VARLEN_FUNC, 3
        return None, None, None
    if version == 2:
        if FLASH_ATTN_2_AVAILABLE:
            return _FA2_FLASH_FUNC, _FA2_VARLEN_FUNC, 2
        return None, None, None
    if FLASH_ATTN_3_AVAILABLE:
        return _FA3_FLASH_FUNC, _FA3_VARLEN_FUNC, 3
    if FLASH_ATTN_2_AVAILABLE:
        return _FA2_FLASH_FUNC, _FA2_VARLEN_FUNC, 2
    return None, None, None


def _can_try_flash(q, k, v):
    if _DISABLE_FLASH:
        return False
    if not (FLASH_ATTN_3_AVAILABLE or FLASH_ATTN_2_AVAILABLE):
        return False
    if not (q.is_cuda and k.is_cuda and v.is_cuda):
        return False
    if q.dim() != 4 or k.dim() != 4 or v.dim() != 4:
        return False
    if q.dtype not in (torch.float16, torch.bfloat16):
        return False
    if k.dtype != q.dtype or v.dtype != q.dtype:
        return False
    return True


def _flash_or_fallback(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    dropout_p: float = 0.0,
    softmax_scale=None,
    q_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    deterministic: bool = False,
    dtype=torch.bfloat16,
    version=None,
):
    if q_scale is not None:
        q = q * q_scale

    if not _can_try_flash(q, k, v):
        return _sdpa_fallback(
            q=q,
            k=k,
            v=v,
            q_lens=q_lens,
            k_lens=k_lens,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            q_scale=None,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic,
            dtype=dtype,
        )

    flash_func, varlen_func, _impl_version = _choose_flash_impl(version=version)
    if flash_func is None:
        return _sdpa_fallback(
            q=q,
            k=k,
            v=v,
            q_lens=q_lens,
            k_lens=k_lens,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            q_scale=None,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic,
            dtype=dtype,
        )

    try:
        q = q.contiguous()
        k = k.contiguous()
        v = v.contiguous()

        if q_lens is None and k_lens is None:
            return flash_func(
                q,
                k,
                v,
                dropout_p=dropout_p,
                softmax_scale=softmax_scale,
                causal=causal,
                window_size=window_size,
                deterministic=deterministic,
            )

        q_lens_list = _normalize_lens(q_lens, q.shape[0], q.shape[1])
        k_lens_list = _normalize_lens(k_lens, k.shape[0], k.shape[1])
        if varlen_func is None or q_lens_list is None or k_lens_list is None:
            return _sdpa_fallback(
                q=q,
                k=k,
                v=v,
                q_lens=q_lens,
                k_lens=k_lens,
                dropout_p=dropout_p,
                softmax_scale=softmax_scale,
                q_scale=None,
                causal=causal,
                window_size=window_size,
                deterministic=deterministic,
                dtype=dtype,
            )

        q_unpad, cu_q, max_q = _unpad_varlen(q, q_lens_list)
        k_unpad, cu_k, max_k = _unpad_varlen(k, k_lens_list)
        v_unpad, _, _ = _unpad_varlen(v, k_lens_list)
        out_unpad = varlen_func(
            q_unpad,
            k_unpad,
            v_unpad,
            cu_q,
            cu_k,
            max_q,
            max_k,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic,
        )
        return _pad_varlen(out_unpad, q_lens_list, q.shape[0], q.shape[1]).contiguous()
    except Exception as exc:
        _warn_once(
            "flash",
            f"FlashAttention failed at runtime and WAN is falling back to PyTorch SDPA. Error: {exc}",
        )
        return _sdpa_fallback(
            q=q,
            k=k,
            v=v,
            q_lens=q_lens,
            k_lens=k_lens,
            dropout_p=dropout_p,
            softmax_scale=softmax_scale,
            q_scale=None,
            causal=causal,
            window_size=window_size,
            deterministic=deterministic,
            dtype=dtype,
        )


def flash_attention(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    dropout_p: float = 0.0,
    softmax_scale=None,
    q_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    deterministic: bool = False,
    dtype=torch.bfloat16,
    version=None,
):
    return _flash_or_fallback(
        q=q,
        k=k,
        v=v,
        q_lens=q_lens,
        k_lens=k_lens,
        dropout_p=dropout_p,
        softmax_scale=softmax_scale,
        q_scale=q_scale,
        causal=causal,
        window_size=window_size,
        deterministic=deterministic,
        dtype=dtype,
        version=version,
    )


def attention(
    q,
    k,
    v,
    q_lens=None,
    k_lens=None,
    dropout_p: float = 0.0,
    softmax_scale=None,
    q_scale=None,
    causal: bool = False,
    window_size=(-1, -1),
    deterministic: bool = False,
    dtype=torch.bfloat16,
    fa_version=None,
):
    return flash_attention(
        q=q,
        k=k,
        v=v,
        q_lens=q_lens,
        k_lens=k_lens,
        dropout_p=dropout_p,
        softmax_scale=softmax_scale,
        q_scale=q_scale,
        causal=causal,
        window_size=window_size,
        deterministic=deterministic,
        dtype=dtype,
        version=fa_version,
    )
