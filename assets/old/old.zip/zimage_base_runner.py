"""
FrameVision - Z-Image Base runner (portable/offline, native diffusers)

Executed INSIDE environments/.zimage_base (venv).
Usage:
  python helpers/zimage_base_runner.py <job_json_path>

Portable/offline rules:
- All HuggingFace + Transformers caches are forced inside FrameVision folders.

Supports:
- Base pipeline loaded from models/zimage_base/base_repo/ (preferred, offline)
- Optional distilled override: "*Diffusion-models*.safetensors" loaded into pipe.transformer (strict=False)
- Optional LoRA: file from models/loras/zimage/ applied via diffusers load_lora_weights + adapter scaling

Output:
- Saves a single PNG to out_path.
"""
from __future__ import annotations

import json
import os
import sys
import traceback

def _read_json(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def _ensure_dir(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)

def _pick_device():
    import torch
    if torch.cuda.is_available():
        return "cuda"
    return "cpu"

def _looks_like_aio_checkpoint(model_path: str) -> bool:
    name = os.path.basename(model_path).lower()
    return ("aio" in name) or ("checkpoint" in name) or ("ckpt" in name)

def _looks_like_diffusion_models(model_path: str) -> bool:
    name = os.path.basename(model_path).lower()
    return ("diffusion-model" in name) or ("diffusion_models" in name) or ("diffusion-models" in name)

def _configure_local_caches(hf_home: str) -> None:
    os.makedirs(hf_home, exist_ok=True)
    os.environ["HF_HOME"] = hf_home
    os.environ["HF_HUB_CACHE"] = os.path.join(hf_home, "hub")
    os.environ["HUGGINGFACE_HUB_CACHE"] = os.path.join(hf_home, "hub")
    os.environ["TRANSFORMERS_CACHE"] = os.path.join(hf_home, "transformers")
    os.environ["XDG_CACHE_HOME"] = hf_home
    # extra: keep torch extensions local if they ever appear
    os.environ.setdefault("TORCH_HOME", os.path.join(hf_home, "torch"))

def _apply_lora(pipe, lora_path: str, strength: float) -> None:
    """
    Best-effort LoRA application across diffusers versions.
    """
    if not lora_path:
        return
    if not os.path.isfile(lora_path):
        raise FileNotFoundError(lora_path)

    # Newer diffusers: load_lora_weights + set_adapters or fuse_lora
    try:
        pipe.load_lora_weights(lora_path, adapter_name="zimg")
        # Preferred: set_adapters with weights
        if hasattr(pipe, "set_adapters"):
            pipe.set_adapters(["zimg"], adapter_weights=[float(strength)])
            return
        # Fallback: fuse_lora
        if hasattr(pipe, "fuse_lora"):
            pipe.fuse_lora(lora_scale=float(strength))
            return
        return
    except Exception:
        # Older paths: try without adapter_name
        pass

    try:
        pipe.load_lora_weights(lora_path)
        if hasattr(pipe, "fuse_lora"):
            pipe.fuse_lora(lora_scale=float(strength))
    except Exception as e:
        raise RuntimeError(f"Failed applying LoRA: {e}") from e

def main() -> int:
    if len(sys.argv) < 2:
        print("Missing job json path", file=sys.stderr)
        return 2

    job_path = os.path.abspath(sys.argv[1])
    job = _read_json(job_path)

    framevision_root = os.path.normpath(job.get("framevision_root") or os.path.join(os.path.dirname(__file__), ".."))
    hf_home = os.path.normpath(job.get("hf_home") or os.path.join(framevision_root, "models", "zimage_base", "_hf_home"))
    base_repo_dir = os.path.normpath(job.get("base_repo_dir") or os.path.join(framevision_root, "models", "zimage_base", "base_repo"))

    _configure_local_caches(hf_home)

    prompt = (job.get("prompt") or "").strip()
    neg = (job.get("negative_prompt") or "").strip()
    cfg = float(job.get("cfg") or 1.0)
    steps = int(job.get("steps") or 10)
    seed = int(job.get("seed") or 0)
    width = int(job.get("width") or 1024)
    height = int(job.get("height") or 1024)

    model_path = os.path.abspath(job.get("model_path") or "") if job.get("model_path") else ""
    lora_path = os.path.abspath(job.get("lora_path") or "") if job.get("lora_path") else ""
    lora_strength = float(job.get("lora_strength") or 0.8)

    out_path = os.path.abspath(job.get("out_path") or "")

    if not prompt:
        print("Prompt is empty", file=sys.stderr)
        return 3
    if not out_path.lower().endswith(".png"):
        print(f"Output must be .png: {out_path}", file=sys.stderr)
        return 5

    # Optional model override checks
    if model_path:
        if not os.path.isfile(model_path):
            print(f"Model override not found: {model_path}", file=sys.stderr)
            return 4
        if _looks_like_aio_checkpoint(model_path) and not _looks_like_diffusion_models(model_path):
            print("Selected override looks like an AIO/Checkpoint file.", file=sys.stderr)
            print("Native diffusers loading for these files is not reliable.", file=sys.stderr)
            print("Fix: use '*Diffusion-models*.safetensors' or just run '(base repo)' with a LoRA.", file=sys.stderr)
            return 11

    _ensure_dir(out_path)

    import torch
    device = _pick_device()
    dtype = torch.bfloat16 if device == "cuda" else torch.float32

    # --- Load base Z-Image pipeline ---
    try:
        from diffusers import ZImagePipeline
    except Exception as e:
        print("Your diffusers build does not include ZImagePipeline.", file=sys.stderr)
        print("Re-run the Z-Image Base installer to upgrade diffusers.", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 9

    base_src = base_repo_dir if os.path.isdir(base_repo_dir) else "Tongyi-MAI/Z-Image-Turbo"

    try:
        pipe = ZImagePipeline.from_pretrained(
            base_src,
            torch_dtype=dtype,
            local_files_only=os.path.isdir(str(base_src)),
        )
    except Exception as e:
        print("Failed to load base pipeline.", file=sys.stderr)
        print("If you are offline, ensure models/zimage_base/base_repo exists.", file=sys.stderr)
        print(str(e), file=sys.stderr)
        return 12

    # Optional: inject distilled transformer weights
    if model_path and _looks_like_diffusion_models(model_path):
        try:
            from safetensors.torch import load_file
            sd = load_file(model_path)
            missing, unexpected = pipe.transformer.load_state_dict(sd, strict=False)
            print(f"Loaded override weights (missing={len(missing)} unexpected={len(unexpected)})")
        except Exception:
            print("Failed to load override 'Diffusion-models' weights into the Z-Image pipeline.", file=sys.stderr)
            traceback.print_exc()
            return 13

    # Optional: apply LoRA
    if lora_path:
        try:
            _apply_lora(pipe, lora_path, lora_strength)
            print(f"LoRA applied: {os.path.basename(lora_path)} (strength={lora_strength})")
        except Exception:
            print("Failed to apply LoRA.", file=sys.stderr)
            traceback.print_exc()
            return 14

    try:
        pipe.to(device)
    except Exception:
        pass

    gen = torch.Generator(device=device)
    gen.manual_seed(seed)

    kwargs = dict(
        prompt=prompt,
        negative_prompt=neg if neg else None,
        width=width,
        height=height,
        num_inference_steps=steps,
        guidance_scale=cfg,
        generator=gen,
    )

    try:
        if device == "cuda":
            with torch.autocast("cuda", dtype=dtype):
                img = pipe(**kwargs).images[0]
        else:
            img = pipe(**kwargs).images[0]
    except Exception:
        print("Generation failed inside pipeline.", file=sys.stderr)
        traceback.print_exc()
        return 10

    try:
        img.save(out_path)
    except Exception:
        print(f"Failed to save output: {out_path}", file=sys.stderr)
        traceback.print_exc()
        return 15

    print(f"OK: saved {out_path}")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        raise SystemExit(99)
