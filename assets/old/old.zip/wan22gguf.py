"""WAN 2.2 (GGUF) runner for FrameVision.

- Runs WAN 2.2 TI2V 5B GGUF models via sd-cli.exe (stable-diffusion.cpp).
- No downloads here: models should be installed via Optional Installs.

Default folders:
- Models:   <root>/models/wan22gguf/
- Outputs:  <root>/output/wan22gguf/
- Settings: <root>/presets/setsave/wan22gguf.json

Notes:
- Some WAN pipelines use a single diffusion model; others use a HighNoise + LowNoise pair.
  This UI supports both. If HighNoise is empty, only --diffusion-model is passed.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from PySide6.QtCore import Qt, QProcess, QProcessEnvironment, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QWidget,
    QStackedWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QComboBox,
    QLineEdit,
    QPushButton,
    QSpinBox,
    QDoubleSpinBox,
    QCheckBox,
    QFileDialog,
    QTextEdit,
    QMessageBox,
    QSizePolicy,
    QGroupBox,
    QScrollArea,
    QFrame,
    QFormLayout,
)


def _project_root() -> Path:
    try:
        p = Path(__file__).resolve()
        if p.parent.name.lower() == "helpers":
            return p.parent.parent
        return p.parent
    except Exception:
        return Path.cwd().resolve()


def _safe_mkdir(p: Path) -> None:
    try:
        p.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass


def _load_json(path: Path) -> Dict:
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        pass
    return {}


def _save_json(path: Path, data: Dict) -> None:
    try:
        _safe_mkdir(path.parent)
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass


def _is_windows() -> bool:
    return os.name == "nt"


def _find_sd_cli(root: Path) -> Optional[Path]:
    """Try to locate sd-cli.exe used by other GGUF tools."""
    candidates = []

    # Common places in this repo layout
    candidates += [
        root / "sd-cli.exe",
        root / "bin" / "sd-cli.exe",
        root / "presets" / "bin" / "sd-cli.exe",
        root / "presets" / "extra_env" / "sd-cli.exe",
        root / "environments" / "sd" / "sd-cli.exe",
        root / "tools" / "sd" / "sd-cli.exe",
    ]

    # If Qwen tool installed its own stable-diffusion.cpp, it might be here
    candidates += [
        root / "presets" / "qwen" / "sd-cli.exe",
        root / "presets" / "qwen" / "bin" / "sd-cli.exe",
        root / "presets" / "qwen2512" / "sd-cli.exe",
        root / "presets" / "qwen2512" / "bin" / "sd-cli.exe",
    ]

    for c in candidates:
        if c.exists():
            return c

    # Scan shallowly for sd-cli.exe (cheap)
    try:
        for base in [root, root / "presets", root / "environments", root / "tools"]:
            if not base.exists():
                continue
            for p in base.rglob("sd-cli.exe"):
                return p
    except Exception:
        pass

    return None


def _list_files(folder: Path, exts: Tuple[str, ...]) -> List[Path]:
    out: List[Path] = []
    try:
        if folder.exists():
            for p in folder.rglob("*"):
                if p.is_file() and p.suffix.lower() in exts:
                    out.append(p)
    except Exception:
        pass
    return sorted(out)


class Wan22GGUFToolWidget(QWidget):
    def __init__(self, parent: Optional[QWidget] = None, standalone: bool = True) -> None:
        super().__init__(parent)
        self._root = _project_root()
        self._standalone = bool(standalone)

        self._models_dir = (self._root / "models" / "wan22gguf").resolve()
        self._out_dir = (self._root / "output" / "wan22gguf").resolve()
        self._settings_path = (self._root / "presets" / "setsave" / "wan22gguf.json").resolve()

        _safe_mkdir(self._models_dir)
        _safe_mkdir(self._out_dir)

        self._proc = QProcess(self)
        self._proc.setProcessChannelMode(QProcess.MergedChannels)
        self._proc.readyReadStandardOutput.connect(self._read_proc)
        self._proc.finished.connect(self._on_finished)

        env = QProcessEnvironment.systemEnvironment()
        env.insert("PYTHONIOENCODING", "utf-8")
        env.insert("PYTHONUTF8", "1")
        self._proc.setProcessEnvironment(env)

        self._build_ui()
        self._load_settings()
        self._refresh_model_lists()


    # ---------------- UI ----------------

    def _build_ui(self) -> None:
        # Left nav + stacked content to avoid cramped layouts in the main WAN tab.
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(10)

        nav = QVBoxLayout()
        nav.setContentsMargins(0, 0, 0, 0)
        nav.setSpacing(6)

        self._nav_group = None
        try:
            from PySide6.QtWidgets import QButtonGroup
            self._nav_group = QButtonGroup(self)
            self._nav_group.setExclusive(True)
        except Exception:
            self._nav_group = None

        def _mk_nav_btn(text: str, idx: int) -> QPushButton:
            b = QPushButton(text)
            b.setCheckable(True)
            b.setMinimumHeight(36)
            b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            try:
                b.setStyleSheet("padding:6px 10px; text-align:left;")
            except Exception:
                pass
            if self._nav_group is not None:
                self._nav_group.addButton(b, idx)
            b.clicked.connect(lambda: self._stack.setCurrentIndex(idx))
            return b

        self._btn_nav_models = _mk_nav_btn("Models", 0)
        self._btn_nav_prompt = _mk_nav_btn("Prompt", 1)
        self._btn_nav_gen = _mk_nav_btn("Generation", 2)
        self._btn_nav_run = _mk_nav_btn("Run", 3)
        nav.addWidget(self._btn_nav_models)
        nav.addWidget(self._btn_nav_prompt)
        nav.addWidget(self._btn_nav_gen)
        nav.addWidget(self._btn_nav_run)
        nav.addStretch(1)

        nav_wrap = QWidget()
        nav_wrap.setLayout(nav)
        nav_wrap.setMaximumWidth(160)
        root.addWidget(nav_wrap, 0)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(8)

        self._stack = QStackedWidget()
        right.addWidget(self._stack, 1)

        # Log stays visible at the bottom (live output while running)
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMinimumHeight(140)
        right.addWidget(self.log, 0)

        right_wrap = QWidget()
        right_wrap.setLayout(right)
        root.addWidget(right_wrap, 1)


        def _wrap_scroll(page: QWidget) -> QWidget:
            sa = QScrollArea()
            sa.setWidgetResizable(True)
            try:
                sa.setFrameShape(QFrame.NoFrame)
            except Exception:
                pass
            sa.setWidget(page)
            return sa

        # ---------------- Page: Models ----------------
        page_models = QWidget()
        lay_models = QVBoxLayout(page_models)
        lay_models.setContentsMargins(0, 0, 0, 0)
        lay_models.setSpacing(8)

        gb_models = QGroupBox("Models")
        form = QFormLayout(gb_models)
        form.setContentsMargins(10, 10, 10, 10)
        form.setSpacing(8)

        self.cmb_low = QComboBox()
        self.cmb_high = QComboBox()
        self.cmb_t5 = QComboBox()
        self.cmb_vae = QComboBox()

        btn_refresh = QPushButton("Refresh")
        btn_refresh.clicked.connect(self._refresh_model_lists)

        row_low = QHBoxLayout(); row_low.setContentsMargins(0,0,0,0)
        row_low.addWidget(self.cmb_low, 1)
        row_low.addWidget(self._mk_browse_btn(self.cmb_low, "Select low-noise diffusion GGUF", ("GGUF (*.gguf)",)))
        form.addRow("Low-noise diffusion", row_low)

        row_high = QHBoxLayout(); row_high.setContentsMargins(0,0,0,0)
        row_high.addWidget(self.cmb_high, 1)
        row_high.addWidget(self._mk_browse_btn(self.cmb_high, "Select high-noise diffusion GGUF (optional)", ("GGUF (*.gguf)",)))
        form.addRow("High-noise diffusion", row_high)

        row_t5 = QHBoxLayout(); row_t5.setContentsMargins(0,0,0,0)
        row_t5.addWidget(self.cmb_t5, 1)
        row_t5.addWidget(self._mk_browse_btn(self.cmb_t5, "Select UMT5 encoder GGUF", ("GGUF (*.gguf)",)))
        form.addRow("UMT5 encoder", row_t5)

        row_vae = QHBoxLayout(); row_vae.setContentsMargins(0,0,0,0)
        row_vae.addWidget(self.cmb_vae, 1)
        row_vae.addWidget(self._mk_browse_btn(self.cmb_vae, "Select VAE safetensors", ("Safetensors (*.safetensors)",)))

        refresh_row = QHBoxLayout(); refresh_row.setContentsMargins(0,0,0,0)
        refresh_row.addWidget(btn_refresh)
        refresh_row.addStretch(1)
        row_vae.addLayout(refresh_row)
        form.addRow("VAE", row_vae)

        lay_models.addWidget(gb_models)
        lay_models.addStretch(1)
        self._stack.addWidget(_wrap_scroll(page_models))

        # ---------------- Page: Prompt ----------------
        page_prompt = QWidget()
        lay_prompt = QVBoxLayout(page_prompt)
        lay_prompt.setContentsMargins(0, 0, 0, 0)
        lay_prompt.setSpacing(8)

        gb_prompt = QGroupBox("Prompt")
        prompt_form = QFormLayout(gb_prompt)
        prompt_form.setContentsMargins(10, 10, 10, 10)
        prompt_form.setSpacing(8)

        self.txt_prompt = QLineEdit()
        self.txt_prompt.setPlaceholderText("Describe the video...")
        self.txt_negative = QLineEdit()
        self.txt_negative.setPlaceholderText("Negative prompt (optional)")

        prompt_form.addRow("Prompt", self.txt_prompt)
        prompt_form.addRow("Negative", self.txt_negative)
        lay_prompt.addWidget(gb_prompt)
        lay_prompt.addStretch(1)
        self._stack.addWidget(_wrap_scroll(page_prompt))

        # ---------------- Page: Generation ----------------
        page_gen = QWidget()
        lay_gen = QVBoxLayout(page_gen)
        lay_gen.setContentsMargins(0, 0, 0, 0)
        lay_gen.setSpacing(8)

        gb_set = QGroupBox("Generation")
        gen = QFormLayout(gb_set)
        gen.setContentsMargins(10, 10, 10, 10)
        gen.setSpacing(8)

        # Mode: text2video / image2video / first+last
        self.cmb_mode = QComboBox()
        self.cmb_mode.addItem("Text→Video", "t2v")
        self.cmb_mode.addItem("Image→Video (start frame)", "i2v")
        self.cmb_mode.addItem("First+Last→Video", "fl2v")
        gen.addRow("Mode", self.cmb_mode)

        def _pick_image(target: QLineEdit, title: str) -> None:
            try:
                path, _ = QFileDialog.getOpenFileName(self, title, str(self._models_dir), "Images (*.png *.jpg *.jpeg *.webp)")
                if path:
                    target.setText(path)
                    self._save_settings()
            except Exception:
                pass

        self.ed_init = QLineEdit()
        self.ed_init.setPlaceholderText("Start image (optional for I2V)")
        btn_init = QPushButton("Browse")
        btn_init.clicked.connect(lambda: _pick_image(self.ed_init, "Select start image"))
        row_init = QHBoxLayout(); row_init.addWidget(self.ed_init, 1); row_init.addWidget(btn_init)
        gen.addRow("Start image", row_init)

        self.ed_end = QLineEdit()
        self.ed_end.setPlaceholderText("End image (only for First+Last)")
        btn_end = QPushButton("Browse")
        btn_end.clicked.connect(lambda: _pick_image(self.ed_end, "Select end image"))
        row_end = QHBoxLayout(); row_end.addWidget(self.ed_end, 1); row_end.addWidget(btn_end)
        gen.addRow("End image", row_end)

        def _mode_changed() -> None:
            try:
                mode = str(self.cmb_mode.currentData() or "t2v")
                is_i2v = mode in ("i2v", "fl2v")
                is_fl = mode == "fl2v"
                self.ed_init.setEnabled(is_i2v)
                btn_init.setEnabled(is_i2v)
                self.ed_end.setEnabled(is_fl)
                btn_end.setEnabled(is_fl)
            except Exception:
                pass
        self.cmb_mode.currentIndexChanged.connect(_mode_changed)
        _mode_changed()

        self.sp_w = QSpinBox(); self.sp_w.setRange(256, 2048); self.sp_w.setSingleStep(32); self.sp_w.setValue(1280)
        self.sp_h = QSpinBox(); self.sp_h.setRange(256, 2048); self.sp_h.setSingleStep(32); self.sp_h.setValue(720)
        wh_row = QHBoxLayout(); wh_row.addWidget(self.sp_w); wh_row.addWidget(QLabel("x")); wh_row.addWidget(self.sp_h); wh_row.addStretch(1)
        gen.addRow("Resolution", wh_row)

        self.sp_frames = QSpinBox(); self.sp_frames.setRange(1, 240); self.sp_frames.setValue(33)
        self.sp_fps = QSpinBox(); self.sp_fps.setRange(1, 60); self.sp_fps.setValue(12)
        ff_row = QHBoxLayout(); ff_row.addWidget(self.sp_frames); ff_row.addWidget(QLabel("frames")); ff_row.addSpacing(12); ff_row.addWidget(self.sp_fps); ff_row.addWidget(QLabel("fps")); ff_row.addStretch(1)
        gen.addRow("Length", ff_row)

        self.sp_steps = QSpinBox(); self.sp_steps.setRange(1, 80); self.sp_steps.setValue(10)
        self.sp_cfg = QDoubleSpinBox(); self.sp_cfg.setRange(1.0, 20.0); self.sp_cfg.setSingleStep(0.1); self.sp_cfg.setValue(3.5)
        sc_row = QHBoxLayout(); sc_row.addWidget(self.sp_steps); sc_row.addWidget(QLabel("steps")); sc_row.addSpacing(12); sc_row.addWidget(self.sp_cfg); sc_row.addWidget(QLabel("cfg")); sc_row.addStretch(1)
        gen.addRow("Quality", sc_row)

        self.cmb_sampler = QComboBox();
        for s in ["euler", "euler_a", "dpm++2m", "dpm++2m_sde", "heun"]:
            self.cmb_sampler.addItem(s, s)
        self.cmb_scheduler = QComboBox();
        for s in ["simple", "karras"]:
            self.cmb_scheduler.addItem(s, s)
        ss_row = QHBoxLayout(); ss_row.addWidget(self.cmb_sampler); ss_row.addSpacing(12); ss_row.addWidget(self.cmb_scheduler); ss_row.addStretch(1)
        gen.addRow("Sampler / Scheduler", ss_row)

        self.sp_flow_shift = QDoubleSpinBox(); self.sp_flow_shift.setRange(0.0, 32.0); self.sp_flow_shift.setSingleStep(0.5); self.sp_flow_shift.setValue(8.0)
        gen.addRow("Flow shift", self.sp_flow_shift)

        self.chk_fa = QCheckBox("Flash attention (--diffusion-fa)")
        self.chk_fa.setChecked(True)
        self.chk_offload = QCheckBox("Offload to CPU (--offload-to-cpu)")
        self.chk_offload.setChecked(False)
        flags_row = QHBoxLayout(); flags_row.addWidget(self.chk_fa); flags_row.addSpacing(12); flags_row.addWidget(self.chk_offload); flags_row.addStretch(1)
        gen.addRow("Flags", flags_row)

        self.sp_seed = QSpinBox(); self.sp_seed.setRange(-1, 2_147_483_647); self.sp_seed.setValue(-1)
        gen.addRow("Seed (-1 random)", self.sp_seed)

        self.txt_extra = QLineEdit();
        self.txt_extra.setPlaceholderText("Extra sd-cli args (optional). Example: --clip-skip 2")
        gen.addRow("Extra args", self.txt_extra)

        lay_gen.addWidget(gb_set)
        lay_gen.addStretch(1)
        self._stack.addWidget(_wrap_scroll(page_gen))

        # ---------------- Page: Run ----------------
        page_run = QWidget()
        lay_run = QVBoxLayout(page_run)
        lay_run.setContentsMargins(0, 0, 0, 0)
        lay_run.setSpacing(8)

        gb_paths = QGroupBox("Run")
        paths = QFormLayout(gb_paths)
        paths.setContentsMargins(10, 10, 10, 10)
        paths.setSpacing(8)

        self.txt_sdcli = QLineEdit()
        self.txt_sdcli.setPlaceholderText("sd-cli.exe path (auto-detected if possible)")
        btn_pick_sd = QPushButton("Browse")
        btn_pick_sd.clicked.connect(self._browse_sdcli)
        btn_find_sd = QPushButton("Auto-find")
        btn_find_sd.clicked.connect(self._auto_find_sdcli)
        sd_row = QHBoxLayout(); sd_row.addWidget(self.txt_sdcli, 1); sd_row.addWidget(btn_find_sd); sd_row.addWidget(btn_pick_sd)
        paths.addRow("sd-cli", sd_row)

        self.txt_out = QLineEdit(str(self._out_dir))
        btn_out = QPushButton("Browse")
        btn_out.clicked.connect(self._browse_outdir)
        out_row = QHBoxLayout(); out_row.addWidget(self.txt_out, 1); out_row.addWidget(btn_out)
        paths.addRow("Output folder", out_row)

        btn_row = QHBoxLayout()
        self.btn_run = QPushButton("Run")
        self.btn_run.clicked.connect(self._run_clicked)
        self.btn_stop = QPushButton("Stop")
        self.btn_stop.clicked.connect(self._stop)
        self.btn_open_models = QPushButton("Open models folder")
        self.btn_open_models.clicked.connect(lambda: self._open_folder(self._models_dir))
        self.btn_open_out = QPushButton("Open output folder")
        self.btn_open_out.clicked.connect(lambda: self._open_folder(Path(self.txt_out.text().strip() or str(self._out_dir))))
        btn_row.addWidget(self.btn_run)
        btn_row.addWidget(self.btn_stop)
        btn_row.addStretch(1)
        btn_row.addWidget(self.btn_open_models)
        btn_row.addWidget(self.btn_open_out)

        paths.addRow("", btn_row)

        # Extra helpers
        extra_row = QHBoxLayout()
        self.chk_use_queue = QCheckBox("Use queue")
        self.chk_use_queue.setToolTip("Run in background worker (if supported). If not supported, runs directly.")
        self.btn_view_results = QPushButton("View results")
        self.btn_view_results.setToolTip("Open Media Explorer and scan this tool's output folder.")
        self.btn_view_results.clicked.connect(self._on_view_results)
        extra_row.addWidget(self.chk_use_queue)
        extra_row.addStretch(1)
        extra_row.addWidget(self.btn_view_results)
        paths.addRow("", extra_row)

        lay_run.addWidget(gb_paths)
        lay_run.addStretch(1)
        self._stack.addWidget(_wrap_scroll(page_run))

        # Default page selection
        try:
            self._btn_nav_models.setChecked(True)
        except Exception:
            pass
        try:
            self._stack.setCurrentIndex(0)
        except Exception:
            pass

        self._auto_find_sdcli(silent=True)


    def _mk_browse_btn(self, combo: QComboBox, title: str, filters: Tuple[str, ...]) -> QPushButton:
        btn = QPushButton("Browse")
        def _pick() -> None:
            filt = ";;".join(filters)
            path, _ = QFileDialog.getOpenFileName(self, title, str(self._models_dir), filt)
            if path:
                self._combo_set_path(combo, Path(path))
                self._save_settings()
        btn.clicked.connect(_pick)
        return btn


    # ---------------- Models ----------------

    def _combo_set_path(self, cmb: QComboBox, path: Path) -> None:
        sp = str(path)
        # If already present, select it
        for i in range(cmb.count()):
            if str(cmb.itemData(i) or "") == sp:
                cmb.setCurrentIndex(i)
                return
        cmb.insertItem(0, path.name, sp)
        cmb.setCurrentIndex(0)


    def _refresh_model_lists(self) -> None:
        low_files = _list_files(self._models_dir, (".gguf",))
        vae_files = _list_files(self._models_dir, (".safetensors",))

        # Heuristics
        low_candidates = [p for p in low_files if "low" in p.name.lower() or "lownoise" in p.name.lower()]
        high_candidates = [p for p in low_files if "high" in p.name.lower() or "highnoise" in p.name.lower()]

        # If no explicit low/high, treat all ggufs as potential low
        if not low_candidates:
            low_candidates = low_files

        # Encoder
        t5_candidates = [p for p in low_files if "umt5" in p.name.lower() or "t5" in p.name.lower()]

        # Diffusion models (exclude t5)
        low_candidates = [p for p in low_candidates if p not in t5_candidates]
        high_candidates = [p for p in high_candidates if p not in t5_candidates]

        def _fill(cmb: QComboBox, items: List[Path], keep: Optional[str] = None, allow_empty: bool = False) -> None:
            cur = keep
            if cur is None:
                try:
                    cur = str(cmb.currentData() or "")
                except Exception:
                    cur = ""
            cmb.blockSignals(True)
            cmb.clear()
            if allow_empty:
                cmb.addItem("(none)", "")
            for p in items:
                cmb.addItem(p.name, str(p))
            # restore
            if cur:
                for i in range(cmb.count()):
                    if str(cmb.itemData(i) or "") == cur:
                        cmb.setCurrentIndex(i)
                        break
            cmb.blockSignals(False)

        _fill(self.cmb_low, low_candidates)
        _fill(self.cmb_high, high_candidates, allow_empty=True)
        _fill(self.cmb_t5, t5_candidates)
        _fill(self.cmb_vae, vae_files)

        # If empty, warn in log
        if self.cmb_low.count() == 0 or self.cmb_t5.count() == 0 or self.cmb_vae.count() == 0:
            self._log("Models folder looks empty. Install WAN2.2 GGUF via Optional Installs (WAN 2.2 GGUF entries).")


    # ---------------- Settings ----------------

    def _load_settings(self) -> None:
        s = _load_json(self._settings_path)
        try:
            self.txt_prompt.setText(str(s.get("prompt", "")))
            self.txt_negative.setText(str(s.get("negative", "")))
            self.sp_w.setValue(int(s.get("w", self.sp_w.value())))
            self.sp_h.setValue(int(s.get("h", self.sp_h.value())))
            self.sp_frames.setValue(int(s.get("frames", self.sp_frames.value())))
            self.sp_fps.setValue(int(s.get("fps", self.sp_fps.value())))
            self.sp_steps.setValue(int(s.get("steps", self.sp_steps.value())))
            self.sp_cfg.setValue(float(s.get("cfg", self.sp_cfg.value())))
            self.sp_flow_shift.setValue(float(s.get("flow_shift", self.sp_flow_shift.value())))
            self.sp_seed.setValue(int(s.get("seed", self.sp_seed.value())))
            self.chk_fa.setChecked(bool(s.get("diffusion_fa", self.chk_fa.isChecked())))
            self.chk_offload.setChecked(bool(s.get("offload", self.chk_offload.isChecked())))
            self.txt_extra.setText(str(s.get("extra_args", "")))
            self.txt_sdcli.setText(str(s.get("sdcli", "")))
            self.txt_out.setText(str(s.get("out_dir", str(self._out_dir))))

            sampler = str(s.get("sampler", ""))
            for i in range(self.cmb_sampler.count()):
                if str(self.cmb_sampler.itemData(i) or "") == sampler or self.cmb_sampler.itemText(i) == sampler:
                    self.cmb_sampler.setCurrentIndex(i)
                    break

            sched = str(s.get("scheduler", ""))
            for i in range(self.cmb_scheduler.count()):
                if str(self.cmb_scheduler.itemData(i) or "") == sched or self.cmb_scheduler.itemText(i) == sched:
                    self.cmb_scheduler.setCurrentIndex(i)
                    break

        except Exception:
            pass

        # Restore model paths later (after refresh)
        self._pending_model_paths = {
            "low": str(s.get("low_model", "")),
            "high": str(s.get("high_model", "")),
            "t5": str(s.get("t5", "")),
            "vae": str(s.get("vae", "")),
        }


    def _save_settings(self) -> None:
        try:
            data = {
                "prompt": self.txt_prompt.text().strip(),
                "negative": self.txt_negative.text().strip(),
                "w": int(self.sp_w.value()),
                "h": int(self.sp_h.value()),
                "frames": int(self.sp_frames.value()),
                "fps": int(self.sp_fps.value()),
                "steps": int(self.sp_steps.value()),
                "cfg": float(self.sp_cfg.value()),
                "flow_shift": float(self.sp_flow_shift.value()),
                "sampler": str(self.cmb_sampler.currentText()),
                "scheduler": str(self.cmb_scheduler.currentText()),
                "seed": int(self.sp_seed.value()),
                "diffusion_fa": bool(self.chk_fa.isChecked()),
                "offload": bool(self.chk_offload.isChecked()),
                "extra_args": self.txt_extra.text().strip(),
                "sdcli": self.txt_sdcli.text().strip(),
                "out_dir": self.txt_out.text().strip(),
                "low_model": str(self.cmb_low.currentData() or ""),
                "high_model": str(self.cmb_high.currentData() or ""),
                "t5": str(self.cmb_t5.currentData() or ""),
                "vae": str(self.cmb_vae.currentData() or ""),
            }
            _save_json(self._settings_path, data)
        except Exception:
            pass


    # ---------------- Actions ----------------

    def _auto_find_sdcli(self, silent: bool = False) -> None:
        found = _find_sd_cli(self._root)
        if found:
            self.txt_sdcli.setText(str(found))
            if not silent:
                self._log(f"Found sd-cli: {found}")
            self._save_settings()
        elif not silent:
            self._log("sd-cli.exe not found. Use Browse or make sure Qwen2512 GGUF tool installed stable-diffusion.cpp.")


    def _browse_sdcli(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select sd-cli.exe", str(self._root), "sd-cli.exe (sd-cli.exe)")
        if path:
            self.txt_sdcli.setText(path)
            self._save_settings()


    def _browse_outdir(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Select output folder", self.txt_out.text().strip() or str(self._out_dir))
        if d:
            self.txt_out.setText(d)
            self._save_settings()


    def _open_folder(self, p: Path) -> None:
        try:
            p = p.resolve()
        except Exception:
            pass
        if not p.exists():
            try:
                _safe_mkdir(p)
            except Exception:
                pass
        try:
            if _is_windows():
                os.startfile(str(p))  # type: ignore
            else:
                import subprocess
                subprocess.Popen(["xdg-open", str(p)])
        except Exception:
            pass


    def _validate(self) -> Optional[str]:
        sdcli = Path(self.txt_sdcli.text().strip())
        if not sdcli.exists():
            return "sd-cli.exe not found. Install Qwen2512 GGUF (optional installs) or browse to sd-cli.exe."

        low = Path(str(self.cmb_low.currentData() or "")).expanduser()
        t5 = Path(str(self.cmb_t5.currentData() or "")).expanduser()
        vae = Path(str(self.cmb_vae.currentData() or "")).expanduser()

        if not low.exists():
            return "Low-noise diffusion GGUF not set. Install WAN 2.2 GGUF via Optional Installs."
        if not t5.exists():
            return "UMT5 encoder GGUF not set. Install WAN 2.2 GGUF via Optional Installs."
        if not vae.exists():
            return "VAE not set. Install WAN 2.2 GGUF via Optional Installs."

        if not self.txt_prompt.text().strip():
            return "Prompt is empty."

        out_dir = Path(self.txt_out.text().strip() or str(self._out_dir))
        _safe_mkdir(out_dir)
        return None


    def _build_cmd(self) -> Tuple[str, List[str], Path]:
        sdcli = Path(self.txt_sdcli.text().strip()).resolve()
        out_dir = Path(self.txt_out.text().strip() or str(self._out_dir)).resolve()

        low = Path(str(self.cmb_low.currentData() or "")).expanduser().resolve()
        high_s = str(self.cmb_high.currentData() or "").strip()
        high = Path(high_s).expanduser().resolve() if high_s else None
        t5 = Path(str(self.cmb_t5.currentData() or "")).expanduser().resolve()
        vae = Path(str(self.cmb_vae.currentData() or "")).expanduser().resolve()

        prompt = self.txt_prompt.text().strip()
        neg = self.txt_negative.text().strip()

        w = int(self.sp_w.value()); h = int(self.sp_h.value())
        frames = int(self.sp_frames.value()); fps = int(self.sp_fps.value())
        steps = int(self.sp_steps.value()); cfg = float(self.sp_cfg.value())
        sampler = str(self.cmb_sampler.currentText())
        scheduler = str(self.cmb_scheduler.currentText())
        flow_shift = float(self.sp_flow_shift.value())
        seed = int(self.sp_seed.value())

        # Output file
        out_path = out_dir / "wan22gguf.mp4"
        # Let sd-cli auto-unique if it supports it; otherwise overwrite.

        args: List[str] = [
            "-M", "vid_gen",
            "--diffusion-model", str(low),
        ]
        if high and high.exists():
            args += ["--high-noise-diffusion-model", str(high)]

        args += [
            "--vae", str(vae),
            "--t5xxl", str(t5),
            "-p", prompt,
            "--cfg-scale", str(cfg),
            "--sampling-method", sampler,
            "--steps", str(steps),
            "-W", str(w),
            "-H", str(h),
            "--video-frames", str(frames),
            "--fps", str(fps),
            "--flow-shift", str(flow_shift),
            "--scheduler", scheduler,
            "-o", str(out_path),
        ]
        # Optional I2V / First+Last (flags depend on sd-cli build).
        try:
            mode = str(getattr(self, 'cmb_mode', None).currentData() or 't2v') if hasattr(self, 'cmb_mode') else 't2v'
            if mode in ('i2v', 'fl2v'):
                init_img = str(getattr(self, 'ed_init', None).text() or '').strip()
                if init_img:
                    args += ['--init-img', init_img]
                if mode == 'fl2v':
                    end_img = str(getattr(self, 'ed_end', None).text() or '').strip()
                    if end_img:
                        args += ['--end-img', end_img]
        except Exception:
            pass


        # If high-noise model exists, mirror settings (common defaults)
        if high and high.exists():
            args += [
                "--high-noise-cfg-scale", str(cfg),
                "--high-noise-sampling-method", sampler,
                "--high-noise-steps", str(steps),
            ]

        if neg:
            args += ["-n", neg]

        if seed >= 0:
            args += ["-s", str(seed)]

        if self.chk_fa.isChecked():
            args += ["--diffusion-fa"]

        if self.chk_offload.isChecked():
            args += ["--offload-to-cpu"]

        extra = self.txt_extra.text().strip()
        if extra:
            # naive split; user can quote if needed
            args += extra.split()

        return (str(sdcli), args, out_dir)



    def _run_clicked(self) -> None:
        """Run directly or enqueue if queue is enabled."""
        try:
            if hasattr(self, 'chk_use_queue') and self.chk_use_queue.isChecked():
                if self._try_enqueue():
                    return
                self._log("Queue not available for WAN22 GGUF on this build — running directly…")
        except Exception:
            pass
        self._run()

    def _try_enqueue(self) -> bool:
        """Best-effort queue integration. Returns True if a job was queued."""
        try:
            # Try common queue adapter entry points (varies across FrameVision builds).
            try:
                from helpers import queue_adapter as qa  # type: ignore
            except Exception:
                import queue_adapter as qa  # type: ignore

            # Candidate functions to enqueue an external command.
            candidates = [
                'enqueue_external_cmd',
                'enqueue_cmd',
                'enqueue_process',
                'enqueue_job',
                'enqueue_generic_job',
            ]
            fn = None
            for name in candidates:
                if hasattr(qa, name):
                    fn = getattr(qa, name)
                    break
            if fn is None:
                return False

            cmd, args, cwd = self._build_cmd()
            out_dir = Path(self.txt_out.text().strip() or str(self._out_dir)).resolve()
            payload = {
                'tool': 'wan22gguf',
                'cmd': cmd,
                'args': args,
                'cwd': str(cwd),
                'out_dir': str(out_dir),
            }
            try:
                r = fn(payload)  # type: ignore[misc]
                return bool(r)
            except TypeError:
                # Some variants take (tool, cmd, args, cwd, out_dir)
                try:
                    r = fn('wan22gguf', cmd, args, str(cwd), str(out_dir))  # type: ignore[misc]
                    return bool(r)
                except Exception:
                    return False
        except Exception:
            return False

    def _on_view_results(self) -> None:
        """Jump to Media Explorer and scan this tool's output folder."""
        out_dir = str(Path(self.txt_out.text().strip() or str(self._out_dir)).resolve())
        main = getattr(self, 'main', None)
        try:
            if main is not None and hasattr(main, 'open_media_explorer_folder'):
                main.open_media_explorer_folder(out_dir, want_images=False, want_videos=True, want_audio=False, include_subfolders=False)
                return
        except Exception:
            pass
        try:
            if main is not None and hasattr(main, 'media_explorer') and hasattr(main, 'tabs'):
                tab = main.media_explorer
                try:
                    if hasattr(tab, 'cb_videos'): tab.cb_videos.setChecked(True)
                    if hasattr(tab, 'cb_images'): tab.cb_images.setChecked(False)
                    if hasattr(tab, 'cb_audio'): tab.cb_audio.setChecked(False)
                    if hasattr(tab, 'cb_subfolders'): tab.cb_subfolders.setChecked(False)
                except Exception:
                    pass
                try:
                    if hasattr(tab, 'set_root_folder'): tab.set_root_folder(out_dir)
                    elif hasattr(tab, 'ed_folder'): tab.ed_folder.setText(out_dir)
                except Exception:
                    pass
                try:
                    main.tabs.setCurrentWidget(tab)
                except Exception:
                    try:
                        for i in range(main.tabs.count()):
                            if main.tabs.widget(i) is tab:
                                main.tabs.setCurrentIndex(i)
                                break
                    except Exception:
                        pass
                try:
                    if hasattr(tab, 'rescan'): tab.rescan()
                except Exception:
                    pass
                return
        except Exception:
            pass
        try:
            QDesktopServices.openUrl(QUrl.fromLocalFile(out_dir))
        except Exception:
            try:
                if os.name == 'nt':
                    os.startfile(out_dir)  # type: ignore[attr-defined]
            except Exception:
                pass

    def _run(self) -> None:
        err = self._validate()
        if err:
            QMessageBox.warning(self, "WAN 2.2 (GGUF)", err)
            return

        # Ensure model selections saved
        self._save_settings()

        cmd, args, cwd = self._build_cmd()
        self._log("\n" + "=" * 60)
        self._log("Running sd-cli:")
        self._log("  " + cmd)
        self._log("  " + " ".join(args))
        self._log("cwd: " + str(cwd))

        try:
            self.btn_run.setEnabled(False)
            self.btn_stop.setEnabled(True)
        except Exception:
            pass

        self._proc.setWorkingDirectory(str(cwd))
        self._proc.start(cmd, args)


    def _stop(self) -> None:
        try:
            if self._proc.state() != QProcess.NotRunning:
                self._proc.kill()
        except Exception:
            pass


    def _read_proc(self) -> None:
        try:
            data = self._proc.readAllStandardOutput().data().decode("utf-8", errors="replace")
            if data:
                self._log(data.rstrip("\n"))
        except Exception:
            pass


    def _on_finished(self, *_):
        try:
            self.btn_run.setEnabled(True)
            self.btn_stop.setEnabled(False)
        except Exception:
            pass


    def _log(self, msg: str) -> None:
        try:
            self.log.append(msg)
        except Exception:
            pass


# Standalone quick test
if __name__ == "__main__":
    from PySide6.QtWidgets import QApplication
    import sys

    app = QApplication(sys.argv)
    w = Wan22GGUFToolWidget(standalone=True)
    w.resize(900, 820)
    w.show()
    sys.exit(app.exec())
