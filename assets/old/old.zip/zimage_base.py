"""
FrameVision - Z-Image Base helper UI (portable/offline)

- Stores settings at: presets/setsave/zimage_base.json
- Loads base pipeline from: models/zimage_base/base_repo/ (no external caches)
- Optional distilled diffusion override: any "*Diffusion-models*.safetensors" in models/zimage_base/
- Optional LoRA: models/loras/zimage/*.safetensors
- Runner: helpers/zimage_base_runner.py executed inside environments/.zimage_base

This file is intentionally self-contained and safe to drop into /helpers/.
"""
from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass, asdict
from typing import Any, Dict, List

from PySide6 import QtCore, QtGui, QtWidgets

SETTINGS_PATH = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "presets", "setsave", "zimage_base.json"))

BASE_REPO_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "models", "zimage_base", "base_repo"))
MODELS_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "models", "zimage_base"))
LORA_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "models", "loras", "zimage"))
HF_HOME_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "models", "zimage_base", "_hf_home"))

RUNNER_PATH = os.path.normpath(os.path.join(os.path.dirname(__file__), "zimage_base_runner.py"))
ENV_PY = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "environments", ".zimage_base", "Scripts", "python.exe"))

def _safe_read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def _safe_write_json(path: str, data: Dict[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)

def _looks_like_aio(name: str) -> bool:
    n = (name or "").lower()
    return ("aio" in n) or ("checkpoint" in n) or ("ckpt" in n)

def _list_safetensors(folder: str) -> List[str]:
    items: List[str] = []
    if os.path.isdir(folder):
        for fn in os.listdir(folder):
            if fn.lower().endswith(".safetensors"):
                items.append(fn)
    items.sort(key=str.lower)
    return items

@dataclass
class ZImageSettings:
    prompt: str = ""
    negative_prompt: str = ""
    cfg: float = 1.0
    steps: int = 10
    seed: int = -1
    width: int = 1024
    height: int = 1024
    sampler: str = "euler"
    scheduler: str = "normal"
    # Model override: either "(base repo)" or a file in MODELS_DIR
    model_choice: str = "(base repo)"
    # LoRA: either "(none)" or a file in LORA_DIR
    lora_choice: str = "(none)"
    lora_strength: float = 0.80
    use_random_seed: bool = True


class ZImageBasePane(QtWidgets.QWidget):
    def __init__(self) -> None:
        super().__init__()
        self._loading = True
        self.setWindowTitle("Z-Image Base — Helper")

        self._build_ui()
        self._load_settings()

    def _build_ui(self) -> None:
        outer = QtWidgets.QVBoxLayout(self)
        outer.setContentsMargins(14, 14, 14, 14)
        outer.setSpacing(10)

        title = QtWidgets.QLabel("Z-Image Base — Quick Settings")
        f = title.font()
        f.setPointSize(18)
        f.setBold(True)
        title.setFont(f)
        outer.addWidget(title)

        # Prompt
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Prompt"), 0)
        self.prompt = QtWidgets.QTextEdit()
        self.prompt.setPlaceholderText("Describe what you want…")
        self.prompt.setMinimumHeight(240)
        row.addWidget(self.prompt, 1)
        outer.addLayout(row)

        # Negative
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Negative"), 0)
        self.negative = QtWidgets.QLineEdit()
        self.negative.setPlaceholderText("Negative prompt (optional)")
        row.addWidget(self.negative, 1)
        outer.addLayout(row)

        # Quality row
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Quality"), 0)
        row.addWidget(QtWidgets.QLabel("CFG"), 0)
        self.cfg = QtWidgets.QDoubleSpinBox()
        self.cfg.setRange(0.0, 20.0)
        self.cfg.setDecimals(2)
        self.cfg.setSingleStep(0.1)
        self.cfg.setValue(1.0)
        row.addWidget(self.cfg, 0)

        row.addWidget(QtWidgets.QLabel("Steps"), 0)
        self.steps = QtWidgets.QSpinBox()
        self.steps.setRange(1, 200)
        self.steps.setValue(10)
        row.addWidget(self.steps, 0)
        row.addStretch(1)
        outer.addLayout(row)

        # Seed row
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Seed"), 0)
        self.seed = QtWidgets.QLineEdit()
        self.seed.setFixedWidth(160)
        self.seed.setPlaceholderText("-1")
        row.addWidget(self.seed, 0)
        self.use_random_seed = QtWidgets.QCheckBox("Random")
        self.use_random_seed.setChecked(True)
        row.addWidget(self.use_random_seed, 0)
        row.addStretch(1)
        outer.addLayout(row)

        # Resolution row
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Resolution"), 0)
        row.addWidget(QtWidgets.QLabel("W"), 0)
        self.width = QtWidgets.QSpinBox()
        self.width.setRange(64, 4096)
        self.width.setSingleStep(64)
        self.width.setValue(1024)
        row.addWidget(self.width, 0)
        row.addWidget(QtWidgets.QLabel("H"), 0)
        self.height = QtWidgets.QSpinBox()
        self.height.setRange(64, 4096)
        self.height.setSingleStep(64)
        self.height.setValue(1024)
        row.addWidget(self.height, 0)
        row.addStretch(1)
        outer.addLayout(row)

        # Sampler/scheduler row (kept for UI consistency; runner currently ignores)
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Sampler"), 0)
        self.sampler = QtWidgets.QComboBox()
        self.sampler.addItems(["euler", "ddim", "dpmpp"])
        self.sampler.setCurrentText("euler")
        row.addWidget(self.sampler, 1)
        self.scheduler = QtWidgets.QComboBox()
        self.scheduler.addItems(["normal", "simple"])
        self.scheduler.setCurrentText("normal")
        row.addWidget(self.scheduler, 1)
        outer.addLayout(row)

        # Model override row
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("Model"), 0)
        self.model_choice = QtWidgets.QComboBox()
        row.addWidget(self.model_choice, 1)
        outer.addLayout(row)

        # LoRA row
        row = QtWidgets.QHBoxLayout()
        row.addWidget(QtWidgets.QLabel("LoRA"), 0)
        self.lora_choice = QtWidgets.QComboBox()
        row.addWidget(self.lora_choice, 1)
        row.addWidget(QtWidgets.QLabel("Strength"), 0)
        self.lora_strength = QtWidgets.QDoubleSpinBox()
        self.lora_strength.setRange(0.0, 2.0)
        self.lora_strength.setDecimals(2)
        self.lora_strength.setSingleStep(0.05)
        self.lora_strength.setValue(0.80)
        row.addWidget(self.lora_strength, 0)
        outer.addLayout(row)

        # Buttons row
        btns = QtWidgets.QHBoxLayout()
        self.btn_reload = QtWidgets.QPushButton("Reload")
        self.btn_save = QtWidgets.QPushButton("Save")
        self.btn_pick_seed = QtWidgets.QPushButton("Pick Seed")
        self.btn_test_env = QtWidgets.QPushButton("Test Env")
        self.btn_generate = QtWidgets.QPushButton("Generate")
        self.btn_generate.setMinimumWidth(140)

        btns.addWidget(self.btn_reload)
        btns.addWidget(self.btn_save)
        btns.addWidget(self.btn_pick_seed)
        btns.addWidget(self.btn_test_env)
        btns.addStretch(1)
        btns.addWidget(self.btn_generate)
        outer.addLayout(btns)

        self.status = QtWidgets.QLabel("")
        self.status.setStyleSheet("color: #888;")
        outer.addWidget(self.status)

        # Hooks
        self.btn_reload.clicked.connect(self._load_settings)
        self.btn_save.clicked.connect(self._save_settings)
        self.btn_pick_seed.clicked.connect(self._pick_seed)
        self.btn_test_env.clicked.connect(self._test_env)
        self.btn_generate.clicked.connect(self._generate)

        # Initial lists
        self._refresh_models()
        self._refresh_loras()

    def _refresh_models(self) -> None:
        # Show "(base repo)" always, plus optional overrides placed directly in MODELS_DIR.
        files = _list_safetensors(MODELS_DIR)
        self.model_choice.blockSignals(True)
        self.model_choice.clear()
        self.model_choice.addItem("(base repo)")
        if files:
            self.model_choice.addItems(files)
        self.model_choice.blockSignals(False)

    def _refresh_loras(self) -> None:
        files = _list_safetensors(LORA_DIR)
        self.lora_choice.blockSignals(True)
        self.lora_choice.clear()
        self.lora_choice.addItem("(none)")
        if files:
            self.lora_choice.addItems(files)
        self.lora_choice.blockSignals(False)

    def _load_settings(self) -> None:
        self._loading = True
        s = ZImageSettings()
        d = _safe_read_json(SETTINGS_PATH)
        for k, v in d.items():
            if hasattr(s, k):
                setattr(s, k, v)

        self.prompt.setPlainText(s.prompt or "")
        self.negative.setText(s.negative_prompt or "")
        self.cfg.setValue(float(s.cfg or 1.0))
        self.steps.setValue(int(s.steps or 10))
        self.seed.setText("" if int(s.seed or -1) == -1 else str(int(s.seed)))
        self.use_random_seed.setChecked(bool(s.use_random_seed))

        self.width.setValue(int(s.width or 1024))
        self.height.setValue(int(s.height or 1024))
        self._set_combo(self.sampler, s.sampler or "euler")
        self._set_combo(self.scheduler, s.scheduler or "normal")

        self._refresh_models()
        self._refresh_loras()
        self._set_combo(self.model_choice, s.model_choice or "(base repo)")
        self._set_combo(self.lora_choice, s.lora_choice or "(none)")
        self.lora_strength.setValue(float(s.lora_strength or 0.80))

        self.status.setText(f"Loaded: {os.path.relpath(SETTINGS_PATH, os.path.dirname(__file__))}")
        self._loading = False

    def _save_settings(self) -> None:
        if self._loading:
            return
        s = self._collect_settings()
        _safe_write_json(SETTINGS_PATH, asdict(s))
        self.status.setText("Saved settings.")

    def _collect_settings(self) -> ZImageSettings:
        try:
            seed_val = int(self.seed.text().strip() or "-1")
        except Exception:
            seed_val = -1

        return ZImageSettings(
            prompt=self.prompt.toPlainText().strip(),
            negative_prompt=self.negative.text().strip(),
            cfg=float(self.cfg.value()),
            steps=int(self.steps.value()),
            seed=seed_val,
            width=int(self.width.value()),
            height=int(self.height.value()),
            sampler=self.sampler.currentText(),
            scheduler=self.scheduler.currentText(),
            model_choice=self.model_choice.currentText() if self.model_choice.count() else "(base repo)",
            lora_choice=self.lora_choice.currentText() if self.lora_choice.count() else "(none)",
            lora_strength=float(self.lora_strength.value()),
            use_random_seed=bool(self.use_random_seed.isChecked()),
        )

    def _set_combo(self, combo: QtWidgets.QComboBox, value: str) -> None:
        idx = combo.findText(value)
        if idx >= 0:
            combo.setCurrentIndex(idx)

    def _pick_seed(self) -> None:
        self.seed.setText(str(random.randint(0, 2**31 - 1)))
        self.use_random_seed.setChecked(False)
        self.status.setText("Picked a new seed.")

    def _test_env(self) -> None:
        if not os.path.isfile(ENV_PY):
            self.status.setText("Env python not found. Run the installer first.")
            return
        import subprocess
        code = "import torch; print('torch', torch.__version__); print('cuda', torch.cuda.is_available()); print('device', torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'cpu')"
        try:
            out = subprocess.check_output([ENV_PY, "-c", code], stderr=subprocess.STDOUT, text=True)
            self.status.setText(out.strip().replace("\n", " | "))
        except Exception as e:
            self.status.setText(f"Test failed: {e}")

    def _generate(self) -> None:
        if not os.path.isfile(ENV_PY):
            self.status.setText("Env python not found. Run the installer first.")
            return
        if not os.path.isfile(RUNNER_PATH):
            self.status.setText("Runner not found: helpers/zimage_base_runner.py")
            return
        if not os.path.isdir(BASE_REPO_DIR):
            self.status.setText("Base repo not found. Run installer to download models/zimage_base/base_repo.")
            return

        s = self._collect_settings()
        if not s.prompt.strip():
            self.status.setText("Prompt is empty.")
            return

        # Seed handling
        seed_val = s.seed
        if s.use_random_seed or seed_val < 0:
            seed_val = random.randint(0, 2**31 - 1)

        # Model override (optional)
        model_choice = s.model_choice
        model_path = ""
        if model_choice and model_choice != "(base repo)":
            model_path = os.path.join(MODELS_DIR, model_choice)
            if not os.path.isfile(model_path):
                self.status.setText("Selected model file missing. Use '(base repo)' or re-download.")
                return
            if _looks_like_aio(model_choice) and ("diffusion-model" not in model_choice.lower()):
                self.status.setText("AIO/Checkpoint selected. Native diffusers prefers '*Diffusion-models*.safetensors'.")
                return

        # LoRA (optional)
        lora_choice = s.lora_choice
        lora_path = ""
        if lora_choice and lora_choice != "(none)":
            lora_path = os.path.join(LORA_DIR, lora_choice)
            if not os.path.isfile(lora_path):
                self.status.setText("Selected LoRA missing. Check /models/loras/zimage/.")
                return

        # Output path
        import datetime
        out_dir = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "output", "images"))
        os.makedirs(out_dir, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        out_name = f"z-img_{seed_val}_{stamp}.png"
        out_path = os.path.join(out_dir, out_name)

        job = dict(
            prompt=s.prompt,
            negative_prompt=s.negative_prompt,
            cfg=s.cfg,
            steps=s.steps,
            seed=seed_val,
            width=s.width,
            height=s.height,
            sampler=s.sampler,
            scheduler=s.scheduler,
            model_path=model_path,
            lora_path=lora_path,
            lora_strength=float(s.lora_strength),
            out_path=out_path,
            framevision_root=os.path.normpath(os.path.join(os.path.dirname(__file__), "..")),
            hf_home=HF_HOME_DIR,
            base_repo_dir=BASE_REPO_DIR,
        )

        job_path = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "presets", "setsave", "zimage_base_last_job.json"))
        _safe_write_json(job_path, job)

        self.status.setText("Starting generation…")

        import subprocess
        try:
            p = subprocess.run([ENV_PY, RUNNER_PATH, job_path], capture_output=True, text=True)
            if p.returncode == 0:
                self.status.setText(f"Saved: {os.path.relpath(out_path, os.path.join(os.path.dirname(__file__), '..'))}")
            else:
                tail = (p.stderr or p.stdout or "").strip().splitlines()[-8:]
                self.status.setText("Generation failed: " + " | ".join(tail))
        except Exception as e:
            self.status.setText(f"Failed to launch runner: {e}")


def _run_standalone() -> None:
    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    w = ZImageBasePane()
    w.resize(980, 720)
    w.show()
    app.exec()

if __name__ == "__main__":
    _run_standalone()
