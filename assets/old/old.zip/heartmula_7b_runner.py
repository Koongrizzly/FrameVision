#!/usr/bin/env python3
"""
HeartMula Chunk 7B runner.

Called by planner.py using the HeartMula venv python, with a JSON payload.
This script should be kept tiny and robust:
- Writes a tags file
- Locates HeartMuLa example generator script
- Runs it with fixed defaults (3B, topk/temp/cfg) + payload duration + lyrics
- Prints a final JSON line {"out_path": "..."} for the planner to capture
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import subprocess
from pathlib import Path

DEFAULT_VERSION = "3B"
DEFAULT_TOPK = 50
DEFAULT_TEMPERATURE = 1.0
DEFAULT_CFG_SCALE = 1.5

def _read_json(p: Path) -> dict:
    try:
        return json.loads(p.read_text(encoding="utf-8", errors="ignore") or "{}")
    except Exception:
        return {}

def _find_run_script(model_dir: Path) -> Path:
    # Preferred path (bundled source snapshot used by FrameVision optional install)
    cand = model_dir / "_heartlib_src" / "examples" / "run_music_generation.py"
    if cand.exists():
        return cand
    # Fallback: search any example file
    for p in model_dir.rglob("run_music_generation.py"):
        try:
            if p.is_file():
                return p
        except Exception:
            pass
    return cand

def _script_help_flags(py: str, script: Path) -> str:
    try:
        cp = subprocess.run([py, str(script), "-h"], capture_output=True, text=True, timeout=15)
        return (cp.stdout or "") + "\n" + (cp.stderr or "")
    except Exception:
        return ""

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--payload", required=True, help="Path to heartmula_payload.json")
    args = ap.parse_args()

    payload_path = Path(args.payload)
    payload = _read_json(payload_path)

    root = Path(str(payload.get("root") or "")).expanduser()
    if not root:
        root = Path.cwd()

    audio_dir = Path(str(payload.get("audio_dir") or "")).expanduser()
    out_path = Path(str(payload.get("output_path") or "")).expanduser()
    lyrics_path = Path(str(payload.get("lyrics_path") or "")).expanduser()
    style_text = str(payload.get("style_text") or "").strip()

    # Duration
    try:
        dur_s = float(payload.get("duration_sec") or 0.0)
    except Exception:
        dur_s = 0.0
    dur_s = max(1.0, float(dur_s))
    max_audio_ms = int(round(dur_s * 1000.0))

    # Ensure dirs
    try:
        audio_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

    # Write tags file (style text)
    tags_path = audio_dir / "heartmula_tags.txt"
    try:
        tags_path.write_text(style_text + "\n", encoding="utf-8", errors="ignore")
    except Exception:
        # still try without tags file
        pass

    # Model dir (matches UI: models\\HeartMuLa)
    model_dir = root / "models" / "HeartMuLa"
    if not model_dir.exists():
        # fallback common casing
        model_dir = root / "models" / "HeartMula"
    run_script = _find_run_script(model_dir)
    if not run_script.exists():
        raise RuntimeError(f"HeartMuLa run script not found. Looked for: {run_script}")

    py = sys.executable

    # Try to enable more stable CUDA allocations (helps avoid fragmentation/OOM)
    env = os.environ.copy()
    env.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

    # Detect optional flags (dtype/precision) to reduce VRAM if supported by the script
    help_txt = _script_help_flags(py, run_script)
    extra_args: list[str] = []
    ht = help_txt.lower()

    # Prefer bf16, then fp16, only if the script supports a dtype/precision flag
    if "--dtype" in ht:
        extra_args += ["--dtype", "bfloat16"]
    elif "--precision" in ht:
        extra_args += ["--precision", "bf16"]
    elif "--bf16" in ht:
        extra_args += ["--bf16"]
    elif "--fp16" in ht:
        extra_args += ["--fp16"]

    # Build command
    cmd = [
        py, str(run_script),
        f"--model_path={str(model_dir)}",
        f"--version={DEFAULT_VERSION}",
        f"--lyrics={str(lyrics_path)}",
        f"--tags={str(tags_path)}",
        f"--save_path={str(out_path)}",
        f"--max_audio_length_ms={max_audio_ms}",
        f"--topk={DEFAULT_TOPK}",
        f"--temperature={DEFAULT_TEMPERATURE}",
        f"--cfg_scale={DEFAULT_CFG_SCALE}",
    ] + extra_args

    # Stream output so planner can capture into heartmula_log.txt
    sys.stdout.write("[heartmula_runner_cmd] " + " ".join([str(x) for x in cmd]) + "\n")
    sys.stdout.flush()
    proc = subprocess.Popen(cmd, cwd=str(root), stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, bufsize=1)
    assert proc.stdout is not None
    for line in proc.stdout:
        sys.stdout.write(line)
        sys.stdout.flush()
    rc = proc.wait()
    if rc != 0:
        raise RuntimeError(f"HeartMuLa generation failed with code {rc}")

    # Success signal for planner
    sys.stdout.write(json.dumps({"out_path": str(out_path)}) + "\n")
    sys.stdout.flush()
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        # Emit error to stdout so the planner log contains it
        sys.stdout.write(f"[heartmula_7b_runner] ERROR: {e}\n")
        sys.stdout.flush()
        raise
